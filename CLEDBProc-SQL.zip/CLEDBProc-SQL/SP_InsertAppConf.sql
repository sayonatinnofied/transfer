create PROCEDURE SP_InsertAppConf(

@p_applicationId VARCHAR(200),
@p_interfaceId VARCHAR(200),
@p_transactionType VARCHAR(20),
@p_transactionDomain VARCHAR(20))

AS

BEGIN

insert into INTERFACECONFIG (APPLICATIONID,INTERFACEID,TRANSACTIONTYPE,TRANSACTIONDOMAIN)
values(@p_applicationId,@p_interfaceId ,@p_transactionType ,@p_transactionDomain);

END
GO
