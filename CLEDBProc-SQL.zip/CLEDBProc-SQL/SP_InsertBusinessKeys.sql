create PROCEDURE SP_InsertBusinessKeys(

@p_transactionId VARCHAR(200),
@p_name VARCHAR(200),
@p_value VARCHAR(200),
@p_type VARCHAR(20))

AS

BEGIN

insert into BUSINESSKEYS (TRANSACTIONID,NAME,VALUE,TYPE)
values(@p_transactionId,@p_name ,@p_value ,@p_type);

END
GO