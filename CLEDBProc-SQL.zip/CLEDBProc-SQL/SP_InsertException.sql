CREATE PROCEDURE SP_InsertException(

@p_applicationid VARCHAR(50),					
@p_componentname VARCHAR(200),						
@p_hostname VARCHAR(20),					
@p_timestamp DATE,					
@p_transactiondomain VARCHAR(20),					
@p_transactiontype VARCHAR(20),						
@p_transactionid VARCHAR(50),					
@p_correlationid VARCHAR(50),					
@p_interfaceid VARCHAR(100),						
@p_filename VARCHAR(50),						
@p_message VARCHAR(500),								
@p_renderid VARCHAR(50),							
@p_dataencoding VARCHAR(20),						
@p_transaction VARCHAR(5000),						
@p_exceptioninstanceid VARCHAR(50),					
@p_exceptioncode VARCHAR(20),						
@p_category VARCHAR(20),							
@p_type VARCHAR(20),								
@p_severity VARCHAR(20),							
@p_timeout VARCHAR(20),								
@p_replydestination VARCHAR(20),					
@p_notificationchannel VARCHAR(20),					
@p_resolutiondescription VARCHAR(20),				
@p_status VARCHAR(20),								
@p_transactiondataafterresolve VARCHAR(5000),			
@p_custom VARCHAR(20),								
@p_resolvedelaytime VARCHAR(20),					
@p_eventtype VARCHAR(20),							
@p_stacktrace VARCHAR(5000),							
@p_description VARCHAR(1000),							
@p_processstack VARCHAR(5000),						
@p_processname VARCHAR(200),							
@p_activityname VARCHAR(200),						
@p_operationname VARCHAR(20),						
@p_payload VARCHAR(5000))

AS

BEGIN
insert into EXCEPTIONS(APPLICATIONID,COMPONENTNAME,HOSTNAME,TIMESTAMP,TRANSACTIONDOMAIN,TRANSACTIONTYPE,TRANSACTIONID,CORRELATIONID,INTERFACEID,FILENAME,MESSAGE,RENDERID,DATAENCODING,[TRANSACTION],EXCEPTIONINSTANCEID,EXCEPTIONCODE,CATEGORY,TYPE,SEVERITY,TIMEOUT,REPLYDESTINATION,NOTIFICATIONCHANNEL,RESOLUTIONDESCRIPTION,STATUS,TRANSACTIONDATAAFTERRESOLVE,CUSTOM,RESOLVEDELAYTIME,EVENTTYPE,STACKTRACE,DESCRIPTION,PROCESSSTACK,PROCESSNAME,ACTIVITYNAME,OPERATIONNAME,PAYLOAD)
values(@p_applicationid,@p_componentname,@p_hostname,@p_timestamp,@p_transactiondomain,@p_transactiontype,@p_transactionid,@p_correlationid,@p_interfaceid,@p_filename,@p_message,@p_renderid,@p_dataencoding,@p_transaction,@p_exceptioninstanceid,@p_exceptioncode,@p_category,@p_type,@p_severity,@p_timeout,@p_replydestination,@p_notificationchannel,@p_resolutiondescription,@p_status,@p_transactiondataafterresolve,@p_custom,@p_resolvedelaytime,@p_eventtype,@p_stacktrace,@p_description,@p_processstack,@p_processname,@p_activityname,@p_operationname,@p_payload);

END
GO