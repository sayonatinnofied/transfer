create PROCEDURE SP_InsertLogDetails(
@p_applicationId VARCHAR(200),
@p_interfaceId VARCHAR(200),
@p_transactionType VARCHAR(20),
@p_transactionDomain VARCHAR(20),
@p_logLevel VARCHAR(20),
@p_generalLogMsg VARCHAR(5000),
@p_status VARCHAR(20),
@p_transactionID VARCHAR(50),
@p_processName VARCHAR(200),
@p_logCorrelationId VARCHAR(20),
@p_logTimeStamp VARCHAR(20),
@p_operationName VARCHAR(20),
@p_payload VARCHAR(5000))
AS
BEGIN
insert into LOGS (APPLICATIONID,INTERFACEID,TRANSACTIONTYPE,TRANSACTIONDOMAIN,LOGLEVEL,GENERALLOGMSG,STATUS,TRANSACTIONID,PROCESSNAME,LOGCORRELATIONID,LOGTIMESTAMP,OPERATIONNAME,PAYLOAD)
values(@p_applicationId,@p_interfaceId ,@p_transactionType ,@p_transactionDomain,@p_logLevel,@p_generalLogMsg,@p_status,@p_transactionID,@p_processName,@p_logCorrelationId,@p_logTimeStamp,@p_operationName,@p_payload);

END
GO