CREATE PROCEDURE SP_RetrieveExceptionConfig
(
@p_applicationId VARCHAR(200),
@p_interfaceId VARCHAR(200),
@p_exceptioncode VARCHAR(20),
@p_categoryname VARCHAR(20) OUT,
@p_typename VARCHAR(20) OUT,
@p_severityname VARCHAR(20) OUT,
@p_procedurename VARCHAR(200) OUT,
@p_description VARCHAR(500) OUT,
@p_exceptionttl INTEGER OUT,
@p_notificationchannel VARCHAR(20) OUT,
@p_procedurechannel VARCHAR(20) OUT,
@p_physicalprocedurename VARCHAR(200) OUT,
@p_rolename VARCHAR(20) OUT,
@p_emailto VARCHAR(500) OUT,
@p_emailcc VARCHAR(500) OUT,
@p_replydestination VARCHAR(200) OUT,
@p_instruction VARCHAR(1000) OUT,
@p_eventtype VARCHAR(20) OUT,
@p_resolvedelayinterval INTEGER OUT)

AS 

BEGIN

SELECT CATEGORYNAME As [@p_categoryname], 
       TYPENAME As [@p_typename], 
       SEVERITYNAME As [@p_severityname],  
       PROCEDURENAME As [@p_procedurename],
       DESCRIPTION As [@p_description],
       EXCEPTIONTTL As [@p_exceptionttl],
       NOTIFICATIONCHANNEL As [@p_notificationchannel], 
       PROCEDURECHANNEL As [@p_procedurechannel], 
       PHYSICALPROCEDURENAME As [@p_physicalprocedurename], 
       ROLENAME As [@p_rolename], 
       EMAILTO As [@p_emailto],
       EMAILCC As [@p_emailcc],
       REPLYDESTINATION As [@p_replydestination], 
       INSTRUCTION As [@p_instruction],
       EVENTTYPE As [@p_eventtype],
       RESOLVEDELAYINTERVAL As [@p_resolvedelayinterval] 
FROM [dbo].[EXCEPTIONCONFIG]
WHERE APPLICATIONID=@p_applicationId OR INTERFACEID=@p_interfaceId OR EXCEPTIONCODE=@p_exceptioncode;

END
GO