create PROCEDURE SP_RetrieveInterfaceConfig
(
@p_applicationId VARCHAR(200),
@p_interfaceId VARCHAR(200) OUT,
@p_transactionType VARCHAR(20) OUT,
@p_transactionDomain VARCHAR(20) OUT
)

AS

BEGIN

SELECT INTERFACEID AS [@p_interfaceId], TRANSACTIONDOMAIN AS [@p_transactionDomain],TRANSACTIONTYPE AS [@p_transactionType]
FROM [dbo].[INTERFACECONFIG]
WHERE APPLICATIONID=@p_applicationId;

END
GO