create PROCEDURE SP_SearchLogs(
@p_applicationId VARCHAR(200) OUT,
@p_interfaceid VARCHAR(200) OUT, 
@p_transactiontype VARCHAR(20) OUT, 
@p_transactiondomain VARCHAR(20) OUT, 
@p_loglevel VARCHAR(20) OUT, 
@p_generallogmsg VARCHAR(5000) OUT, 
@p_status VARCHAR(20) OUT, 
@p_transactionid VARCHAR(200) OUT,
@p_processname VARCHAR(200) OUT,
@p_logcorrelationid VARCHAR(20) OUT, 
@p_logtimestamp VARCHAR(20) OUT,
@p_operationname VARCHAR(20) OUT,
@p_payload VARCHAR(5000) OUT,
@p_appId VARCHAR(200),
@p_intId VARCHAR(200),
@p_tranId VARCHAR(200),
@p_timestamp VARCHAR(20))

AS

BEGIN

SELECT @p_applicationId,@p_interfaceid, @p_transactiontype, @p_transactiondomain, @p_loglevel, @p_generallogmsg, @p_status, @p_transactionid,@p_processname,@p_logcorrelationid,@p_logtimestamp,@p_operationname,@p_payload FROM [dbo].[LOGS]
WHERE 
APPLICATIONID=@p_appId AND INTERFACEID=@p_intId AND TRANSACTIONID=@p_tranId AND LOGTIMESTAMP=@p_timestamp;

END
GO




