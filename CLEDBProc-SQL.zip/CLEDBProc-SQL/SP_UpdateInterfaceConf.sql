create Procedure SP_UpdateInterfaceConf(

@p_applicationId VARCHAR(200),
@p_interfaceId VARCHAR(200),
@p_transactionType VARCHAR(20),
@p_transactionDomain VARCHAR(20))

AS

BEGIN

update INTERFACECONFIG set TRANSACTIONTYPE=@p_transactionType,TRANSACTIONDOMAIN=@p_transactionDomain where
APPLICATIONID=@p_applicationId and INTERFACEID=@p_interfaceId;


END
GO
