create PROCEDURE SP_UpdateExceptionStatus
(
@p_transactionId VARCHAR(50),
@p_exceptionsinstanceId VARCHAR(50),
@p_exceptionstatus VARCHAR(20)
)

AS 

BEGIN

UPDATE EXCEPTIONS
SET  STATUS = @p_exceptionstatus       
WHERE  TRANSACTIONID =@p_transactionId AND EXCEPTIONINSTANCEID =@p_exceptionsinstanceId; 

END
GO