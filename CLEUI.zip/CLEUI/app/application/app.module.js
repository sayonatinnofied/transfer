'use strict';

require('./directives');
require('./services');

var util = require('../util/util');

// constants
var TEMPLATE_PATH = '/template/treasure-overlay-spinner/treasure-overlay-spinner.html';
var TEMPLATE = '';
TEMPLATE += '<div class="treasure-overlay-spinner-content">';
TEMPLATE += '<div class="treasure-overlay-spinner-container">';
TEMPLATE += '<div class="treasure-overlay-spinner"></div>';
TEMPLATE += '</div>';
TEMPLATE += '<ng-transclude></ng-transclude>';
TEMPLATE += '</div>';

var App = angular.module('app', ['ui.bootstrap', 'ui.bootstrap.datetimepicker', 'toastr', 'angular-loading-bar', 'ngAnimate', 'ngSanitize', 'ngDialog', 'ngCsv', 'ui.router', 'ui.select', 'app.directive', 'app.service'])
  .filter("niceDate", function () {
    return function (dateStr) {
      var formattedDate = '';
      if (dateStr == undefined) {
        dateStr = '';
      } else {
        formattedDate = new Date(dateStr.replace(/-/g, "/").replace(/T/g, " ")).toDateString();
      }
      return formattedDate;
    }
  })
  .filter("niceTimeStamp", function () {
    return function (timeStamp) {
      var formattedDate = '';
      if (timeStamp == undefined) {
        timeStamp = '';
      } else {
        formattedDate = new Date(timeStamp).toLocaleString();
      }
      return formattedDate;
    }
  }).filter('propsFilter', function () {
    return function (items, props) {
      var out = [];

      if (angular.isArray(items)) {
        var keys = Object.keys(props);

        items.forEach(function (item) {
          var itemMatches = false;

          for (var i = 0; i < keys.length; i++) {
            var prop = keys[i];
            var text = props[prop].toLowerCase();
            if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {
              itemMatches = true;
              break;
            }
          }

          if (itemMatches) {
            out.push(item);
          }
        });
      } else {
        // Let the output be the input untouched
        out = items;
      }

      return out;
    };
  })
  .animation('.fadeInOut', function () {
    return {
      enter: function (element, done) {
        element.css('display', 'none');
        $(element).fadeIn(200, function () {
          done();
        });
      },
      leave: function (element, done) {
        $(element).fadeOut(200, function () {
          done();
        });
      },
      add: function (element, done) {
        element.css('display', 'none');
        $(element).fadeIn(200, function () {
          done();
        });
      },
      remove: function (element, done) {
        $(element).fadeOut(200, function () {
          done();
        });
      },
      move: function (element, done) {
        element.css('display', 'none');
        $(element).slideDown(200, function () {
          done();
        });
      }
    }
  })
  .animation('.slideInOut', function () {
    return {
      enter: function (element, done) {
        element.css('display', 'none');
        $(element).slideDown('slow', function () {
          done();
        });
      },
      leave: function (element, done) {
        $(element).slideUp('slow', function () {
          done();
        });
      },
      move: function (element, done) {
        element.css('display', 'none');
        $(element).slideDown('slow', function () {
          done();
        });
      }
    }
  })
  .controller('loginCtrl', require('./controllers/loginCtrl'))
  .controller('clebaseCtrl', require('./controllers/clebaseCtrl'))
  .controller('dashboardCtrl', require('./controllers/dashboardCtrl'))
  .controller('configurationCtrl', require('./controllers/configurationCtrl'))
  .controller('logHistoryCtrl', require('./controllers/logHistoryCtrl'))
  .controller('exceptionHistoryCtrl', require('./controllers/exceptionHistoryCtrl'))
  .controller('exceptionDetailsCtrl', require('./controllers/exceptionDetailsCtrl'))
  .controller('logDetailsCtrl', require('./controllers/logDetailsCtrl'))
  .config(require('./router/router'))
  .config(['$qProvider', function ($qProvider) {
    $qProvider.errorOnUnhandledRejections(false);
  }])
  .run(function ($rootScope, $http, $templateCache) {

    $rootScope.appStarted = true;

    $rootScope.spinner = {
      active: false,
      on: function () {
        this.active = true;
      },
      off: function () {
        this.active = false;
      }
    };

    $templateCache.put(TEMPLATE_PATH, TEMPLATE);

  });

module.exports = App;
