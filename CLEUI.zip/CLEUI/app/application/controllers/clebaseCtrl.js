'use strict';

var format = require('../../util/format');
var util = require('../../util/util');

module.exports = function($scope, $rootScope, $state, $http, $timeout, toastr, cfpLoadingBar) {
	console.log("Navigated to cle base.");

    if(!util.getLocalStorage('login') || !$rootScope.user) {
        $state.go('login');
    }

    $scope.user = $rootScope.user;
    $rootScope.urlConfig = null;

    /********************** Set up a root scope object *******************/
    
    $rootScope.LogMsgRequest = angular.copy(format.LogMsgRequest);
    $rootScope.LogMsgRequest.LogMsgHeader = angular.copy(format.LogMsgHeader);
    $rootScope.LogMsgRequest.LogMsgDescription = angular.copy(format.LogMsgDescription);

    // LOG VARS
    $rootScope.logHistory = angular.copy(format.logHistory);
    $rootScope.logHistory.logs = angular.copy(format.logs);
    $rootScope.logHistory.searchLogHistory = angular.copy(format.searchLogHistory);
    $rootScope.logHistory.config = angular.copy(format.logConfig);
    // EXCEPTION VARS
    $rootScope.exceptionHistory = angular.copy(format.exceptionHistory);
    $rootScope.exceptionHistory.exceptions = angular.copy(format.exceptions);
    $rootScope.exceptionHistory.searchExceptionHistory = angular.copy(format.searchExceptionHistory);
    $rootScope.exceptionHistory.config = angular.copy(format.exceptionConfig);

    /********************** Transitions **********************/

    $scope.goBase = function(){
        $state.go('clebase');
    }

    $scope.goDashboard = function(){
        $state.go('clebase.dashboard');
    }

    $scope.goLogHistory = function(){
        $state.go('clebase.loghistory');
    }

    $scope.goExceptionHistory = function(){
        $state.go('clebase.exceptionhistory');
    }

    $scope.goConfigureInterface = function(){
        $state.go('clebase.configureinterface');
    }

    $scope.goRegisterInterface = function(){
        $state.go('clebase.registerinterface');
    }

    $scope.goUpdateInterface = function(){
        $state.go('clebase.updateinterface');
    }

    $scope.goLogDetails = function(transactionId, log) {
        $state.go('clebase.logdetails', {id:transactionId, data:log});
    }

    $scope.goExceptionDetails = function(transactionId, exception) {
        $state.go('clebase.exceptiondetails', {id:transactionId, data:exception});
    }

    /********************** Functions ******************************/

    $scope.logout = function(){
        util.deleteLocalStorage('login');
        $state.go('login');
    }
    $rootScope.spinner.on();
    $http.get('urls.json').then(function(res){
        $rootScope.urlConfig = res.data;
        console.log($rootScope.urlConfig);
        $rootScope.spinner.off();             
    });
};