'use strict';
var fs = require('fs');
var format = require('../../util/format');
var util = require('../../util/util');

module.exports = function ($scope, $rootScope, $state, $stateParams, $http, $timeout, toastr, $uibModalInstance, cfpLoadingBar, ngDialog, exception) {
    console.log("Navigated to exception details.", exception);

    $scope.exception = angular.copy(exception);
    $scope.close = function () {
        $uibModalInstance.close();
    };

    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };


    /*********************** CSV Config **************************/

    $scope.exportData = function () {

    }

    $scope.csvConfig = {
        getHeader: function () {
            return Object.keys($scope.exception);
        },
        getData: function () {
            $scope.exceptionArr = [];
            var tempObj = angular.copy($scope.exception);
            tempObj.BusinessKeys = JSON.stringify(tempObj.BusinessKeys);
            console.log(tempObj);
            $scope.exceptionArr.push(tempObj);
            return $scope.exceptionArr;
        },
        seperator: ',',
        lazyLoad: true,
        getFileName: function () {
            return 'SExH_' + $scope.exception.InterfaceID + '_' + util.formatDate(new Date());
        }
    }
};