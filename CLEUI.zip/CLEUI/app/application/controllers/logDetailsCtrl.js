'use strict';
var fs = require('fs');
var format = require('../../util/format');
var util = require('../../util/util');

module.exports = function ($scope, $rootScope, $state, $stateParams, $http, $timeout, toastr, cfpLoadingBar, ngDialog, $uibModalInstance, log) {
    console.log("Navigated to log details.", log);

    $scope.log = angular.copy(log);
    $scope.close = function () {
        $uibModalInstance.close();
    };

    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };


    /*********************** CSV Config **************************/

    $scope.exportData = function () {

    }

    $scope.csvConfig = {
        getHeader: function () {
            return Object.keys($scope.log);
        },
        getData: function () {
            $scope.logArr = [];
            var tempObj = angular.copy($scope.log);
            tempObj.BusinessKeys = JSON.stringify(tempObj.BusinessKeys);
            console.log(tempObj);
            $scope.logArr.push(tempObj);
            return $scope.logArr;
        },
        seperator: ',',
        lazyLoad: true,
        getFileName: function () {
            return 'SLoH_' + $scope.log.InterfaceId + '_' + util.formatDate(new Date());
        }
    }
};