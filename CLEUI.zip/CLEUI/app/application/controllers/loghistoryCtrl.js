'use strict';

var format = require('../../util/format');
var util = require('../../util/util');

module.exports = function ($scope, $rootScope, $state, $http, $timeout, $interval, toastr, cfpLoadingBar, $stateParams, $uibModal, $document, $log) {

    console.log("Navigated to log history.");

    // Root State Saves
    $scope.config = $rootScope.logHistory.config;
    $scope.searchLogHistory = $rootScope.logHistory.searchLogHistory;
    $scope.logs = $rootScope.logHistory.logs;


    console.log("Previous State Values: ", $rootScope.logHistory);

    // Locals
    $scope.LogMsgCollection = angular.copy(format.LogMsgCollection);
    $scope.searchOpen = true;
    $scope.logItems = null;
    $scope.interfaceId = null;
    $scope.emptyText = "No items to show";

    $scope.freshHeader = {};
    $scope.allData = [];

    $scope.isValidForm = false;

    /******************** Date Config *********************/

    $scope.startDate = {
        minDate: null,
        maxDate: null
    };

    $scope.endDate = {
        minDate: null,
        maxDate: null
    };

    $scope.open = function (op) {
        switch (op) {
            case 1:
                $scope.status.startDate = true;
                break;
            case 2:
                $scope.status.endDate = true;
                break;
            default:
                break;
        }
    };

    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.format = 'yyyy-MM-dd';

    $scope.status = {
        startDate: false,
        endDate: false
    };

    /*********************** Pagination **********************/

    $scope.itemsPerPage = 20;
    $scope.maxSize = 5;

    /********************** Functions ************************/

    $scope.makeLogHTTPRequest = function (params, callback) {
        var req = angular.copy($rootScope.urlConfig.logHistoryRequest);
        req.params = params;
        $rootScope.spinner.on();
        console.log("Calling to get log results:: ", params);
        $http(req).then(function (res) {
            $scope.LogMsgCollection = res.data;
            if (params.Page == undefined) {
                $scope.config.totalLogItems = $scope.LogMsgCollection.NoOfPages * $scope.itemsPerPage;
            }
            angular.forEach($scope.LogMsgCollection.LogMsgRequest, function (value, key) {
                var obj = angular.extend({}, value.LogMsgHeader, value.LogMsgDescription);
                $scope.logs.push(obj);
            });
            toastr.success("Page " + $scope.config.currentLogPage + " log records fetched.");
            console.log(res, params, $scope.config, $scope.logs);
            callback();
        }, function (res) {
            console.log(res);
            if (res.status == -1) {
                toastr.error("Error Connection Timeout");
            } else {
                toastr.error(res.data.message);
            }
            if ($scope.config.currentLogPage = 1) {
                $scope.config.currentLogPage = 0;
            }
            if (params.Page == undefined) {
                $scope.config.totalLogItems = 0;
            }
            $rootScope.spinner.off();
        });
    }

    $scope.isValidReq = function(isFormValid){

        if($scope.config.checked) {
           $scope.isValidForm = ($scope.searchLogHistory.InterfaceID || $scope.searchLogHistory.TransactionID) && $scope.searchLogHistory.LogTimeStampFrom && $scope.searchLogHistory.LogTimeStampTo  ? true : false;
        } else {
           $scope.isValidForm = $scope.searchLogHistory.InterfaceID || $scope.searchLogHistory.TransactionID ? true : false;
        }
        console.log(isFormValid, $scope.isValidForm);
    }

    $scope.advanceSearch = function () {
        console.log($scope.config.checked);
        $scope.searchLogHistory.LogTimeStampTo = undefined;
        $scope.searchLogHistory.LogTimeStampFrom = undefined;
        $scope.$broadcast('start-date-changed');
        $scope.$broadcast('end-date-changed');
    };

    $scope.getLogHistory = function (onEvent) {

        function onSuccess() {
            $scope.config.onSearch = true;
            $scope.interfaceId = $scope.searchLogHistory.InterfaceID;
            $rootScope.spinner.off();
        }

        if (onEvent) {
            $scope.getAllData();
            $scope.searchLogHistory.Page = undefined;
            $scope.config.currentLogPage = 1;
        } else {
            $scope.searchLogHistory.Page = $scope.config.currentLogPage;
        }

        $rootScope.logHistory.logs = [];
        $scope.logs = $rootScope.logHistory.logs;

        $scope.makeLogHTTPRequest($scope.searchLogHistory, onSuccess);
    }

    $scope.getLogDetails = function (log) {
        $scope.open('lg', 'body', log);
    };

    /* Bindable functions -----------------------------------------------*/

    $scope.endDateBeforeRender = endDateBeforeRender
    $scope.endDateOnSetTime = endDateOnSetTime
    $scope.startDateBeforeRender = startDateBeforeRender
    $scope.startDateOnSetTime = startDateOnSetTime

    function startDateOnSetTime() {
        $scope.$broadcast('start-date-changed');
    }

    function endDateOnSetTime() {
        $scope.$broadcast('end-date-changed');
    }

    function startDateBeforeRender($dates) {
        if ($scope.searchLogHistory.LogTimeStampTo) {
            var activeDate = moment($scope.searchLogHistory.LogTimeStampTo);

            $dates.filter(function (date) {
                return date.localDateValue() >= activeDate.valueOf()
            }).forEach(function (date) {
                date.selectable = false;
            })
        }
    }

    function endDateBeforeRender($view, $dates) {
        if ($scope.searchLogHistory.LogTimeStampFrom) {
            var activeDate = moment($scope.searchLogHistory.LogTimeStampFrom).subtract(1, $view).add(1, 'minute');

            $dates.filter(function (date) {
                return date.localDateValue() <= activeDate.valueOf()
            }).forEach(function (date) {
                date.selectable = false;
            })
        }
    }

    /*********************** Table Check Action ******************/

    $scope.changeSelectAll = function (isAllSelected) {
        for (var index in $scope.logItems) {
            $scope.logItems[index].checked = isAllSelected;
        }
    }

    $scope.changeSelectOne = function (log, index) {
        console.log(log.checked);
    }

    $scope.isSelectEnabled = function (arrayFrom) {
        var bool = false;
        for (var index in arrayFrom) {
            if (arrayFrom[index].checked) {
                bool = true;
                break;
            }
        }
        return bool;
    };

    $scope.getSelectedData = function (arrayFrom) {
        var data = [];
        if ($scope.isSelectEnabled(arrayFrom)) {
            for (var index in arrayFrom) {
                var tmp = angular.copy(arrayFrom[index]);
                tmp.BusinessKeys = JSON.stringify(tmp.BusinessKeys);
                if (tmp.checked) {
                    delete tmp.checked;
                    data.push(tmp);
                }
            }
        } else {
            for (var index in arrayFrom) {
                var tmp = angular.copy(arrayFrom[index]);
                tmp.BusinessKeys = JSON.stringify(tmp.BusinessKeys);
                delete tmp.checked;
                data.push(tmp);
            }
        }
        console.log(data);
        return data;
    }

    /*********************** CSV Config **************************/

    $scope.exportData = function () {}

    $scope.csvConfig = {
        getHeader: function () {
            return Object.keys($scope.freshHeader);
        },
        getData: function () {
            return $scope.getSelectedData($scope.logItems);
        },
        seperator: ',',
        lazyLoad: true,
        getFileName: function () {
            return 'LoH_' + $scope.interfaceId + '_' + util.formatDate(new Date());
        }
    }

    /*********************** CSV All Config **************************/

    $scope.getAllData = function(){
        var params = angular.copy($scope.searchLogHistory);
        params.Page = undefined;
        params.AllPages = true;
        $scope.allData = [];
        var req = angular.copy($rootScope.urlConfig.logHistoryRequest);
        req.params = params;
        $rootScope.spinner.on();
        $http(req).then(function (res) {
            var responseData = res.data;
            angular.forEach(responseData.LogMsgRequest, function (value, key) {
                var obj = angular.extend({}, value.LogMsgHeader, value.LogMsgDescription);
                obj.BusinessKeys = JSON.stringify(obj.BusinessKeys);
                $scope.allData.push(obj);
            });
            $scope.freshHeader = angular.copy($scope.allData[0]);
            $rootScope.spinner.off();
        }, function (res) {
            if (res.status == -1) {
                console.log("Error Connection Timeout");
            } else {
                console.log(res.data.message);
            }
            $rootScope.spinner.off();
        });
    };

    $scope.csvAllConfig = {
        getHeader: function () {
            return Object.keys($scope.freshHeader);
        },
        getData: function () {
            return $scope.allData;
        },
        seperator: ',',
        lazyLoad: true,
        getFileName: function () {
            return 'LoH_' + $scope.interfaceId + '_' + util.formatDate(new Date());
        }
    }

    /********************** Sort Config ************************/
    $scope.sortConfig = {
        propertyName: '',
        reverse: false,
        setPropertyName: function (value) {
            this.propertyName = value;
        }
    }

    /********************* Modal ******************************/
    $scope.open = function (size, parentSelector, log) {
        var parentElem = parentSelector ?
            angular.element($document[0].querySelector(parentSelector)) : undefined;

        var modalInstance = $uibModal.open({
            templateUrl: 'app/templates/logdetails.html',
            controller: 'logDetailsCtrl',
            size: size,
            appendTo: parentElem,
            resolve: {
                log: function () {
                    return log;
                }
            }
        });

        modalInstance.result.then(function () {
            $log.info('Modal dismissed at: ' + new Date());
        }, function () {
            $log.info('Modal dismissed at: ' + new Date());
        });
    };

    /********************** Watchers **************************/
    $scope.$watch('config.currentLogPage', function (newValue, oldValue) {
        console.log(oldValue, newValue);
        if (oldValue > 0 && newValue >= 1)  {
            console.log("Calling on page change...");
            $scope.getLogHistory();
        }
    })
};