'use strict';

var format = require('../../util/format');
var util = require('../../util/util');

module.exports = function($scope, $rootScope, $state, $http, $timeout, toastr, cfpLoadingBar) {
    console.log("Navigated to login");
    $rootScope.user = angular.copy(format.user);
    $scope.login = function(){
        $rootScope.spinner.on();
        $http.get("users.json").then(function(response){
            $rootScope.user = response.data;
            util.setLocalStorage('login', true);
            $state.go('clebase.dashboard');
            $rootScope.spinner.off();
        });
    }
};