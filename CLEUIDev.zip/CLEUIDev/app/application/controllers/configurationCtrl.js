'use strict';
var fs = require('fs');
var format = require('../../util/format');
var util = require('../../util/util');

module.exports = function ($scope, $rootScope, $state, $http, $timeout, toastr, cfpLoadingBar, ngDialog) {
    console.log("Navigated to configuration.");

    $scope.configurations = angular.copy(format.configurations);

    $scope.errorCategories = ['Application Exception', 'System Exception'];
    $scope.errorSeverities = ['Low', 'Medium', 'High'];

    $scope.interfaces = [];
    $scope.errorDetails = [];

    $scope.loadDetailsFlag = false;
    $scope.loadErrorCodeFlag = false;

    $scope.updateReq = angular.copy(format.configurations.exception);

    $scope.addConfigurations = function () {
        var req = angular.copy($rootScope.urlConfig.configureInterfaceRequest);
        var data = angular.copy($scope.configurations.exception);
        req.data = JSON.stringify(data);
        console.log(req);
        $rootScope.spinner.on();
        $http(req).then(function (res) {
            toastr.success('Inserted Successfully');
            console.log(res.data);
            $rootScope.spinner.off();
        }, function (res) {
            console.log(res);
            if (res.status == -1) {
                toastr.error("Error Connection Timeout");
            } else {
                if (res.status.toString().startsWith('4')) {
                    toastr.error(res.data.message);
                } else {
                    toastr.error('Failed to insert');
                }
            }
            $rootScope.spinner.off();
        });
    };

    $scope.updateConfigurations = function () {
        var req = angular.copy($rootScope.urlConfig.updateInterfaceRequest);
        req.data = JSON.stringify($scope.updateReq);
        console.log(req);
        $rootScope.spinner.on();
        $http(req).then(function (res) {
            toastr.success('Updated Successfully');
            console.log(res.data);
            $rootScope.spinner.off();
            $scope.getAllInterfaces();
            $scope.updateReq.cleExceptionError[0] = {};
        }, function (res) {
            console.log(res);
            if (res.status == -1) {
                toastr.error("Error Connection Timeout");
            } else {
                toastr.error('Failed to update');
            }
            $rootScope.spinner.off();
        });
    };

    $scope.register = function () {
        var req = angular.copy($rootScope.urlConfig.registerInterfaceRequest);
        req.data = JSON.stringify($scope.configurations.log);
        $rootScope.spinner.on();
        $http(req).then(function (res) {
            toastr.success('Registered Successfully');
            console.log(res.data);
            $rootScope.spinner.off();
        }, function (res) {
            console.log(res);
            if (res.status == -1) {
                toastr.error("Error Connection Timeout");
            } else {
                if (res.status.toString().startsWith('4')) {
                    toastr.error(res.data.message);
                } else {
                    toastr.error('Failed to register');
                }
            }
            $rootScope.spinner.off();
        });

        console.log($scope.configurations.log);
    };

    $scope.getAllInterfaces = function () {
        var req = angular.copy($rootScope.urlConfig.getallinterfaces);

        $rootScope.spinner.on();
        $http(req).then(function (res) {
            console.log(res.data);
            $scope.interfaces = res.data;
            $rootScope.spinner.off();
        }, function (res) {
            console.log(res);
            if (res.status == -1) {
                toastr.error("Error Connection Timeout");
            } else {
                toastr.error('Failed to fetch iterfaces');
            }
            $rootScope.spinner.off();
        });

        console.log($scope.configurations.log);
    };


    $scope.getExceptionDetails = function (interfaceId) {
        $scope.loadErrorCodeFlag = true;
        var req = angular.copy($rootScope.urlConfig.getexceptiondetailsbyid);
        req.params.interfaceId = interfaceId;
        $rootScope.spinner.on();
        $http(req).then(function (res) {
            console.log(res.data);
            $scope.errorDetails = res.data.cleExceptionError;
            $scope.updateReq.cleExceptionError[0] = {};
            $rootScope.spinner.off();
        }, function (res) {
            console.log(res);
            if (res.status == -1) {
                toastr.error("Error Connection Timeout");
            } else {
                toastr.error('Failed to fetch exception details');
            }
            $rootScope.spinner.off();
        });

        console.log($scope.configurations.log);
    };


    /**************************** Setting Box Controls *******************/

    $scope.removeErrorCode = function (index) {
        $scope.type = "Error Code";
        ngDialog.openConfirm({
            template: 'app/templates/popup.html',
            scope: $scope
        }).then(function (value) {
            console.log('Modal promise resolved. Value: ', value);
            if (value) {
                $scope.configurations.exception.cleExceptionError.splice(index, 1);
            }
        }, function (reason) {
            console.log('Modal promise rejected. Reason: ', reason);
        });
    };


    $scope.addErrorCode = function (index) {
        var cleExceptionErrorType = angular.copy(format.configurations.cleExceptionErrorType);
        $scope.configurations.exception.cleExceptionError.push(cleExceptionErrorType);
    };

    /**************************************************************************** */

    $scope.loadExceptionDetails = function (errorDetail) {
        console.log(errorDetail);
        delete errorDetail.$$hashKey;
        $scope.loadDetailsFlag = true;
        $scope.updateReq.cleExceptionError[0] = errorDetail;
        console.log("Final update Request: ", $scope.updateReq);
    }
    if ($scope.interfaces.length == 0)
        $scope.getAllInterfaces();

}; 