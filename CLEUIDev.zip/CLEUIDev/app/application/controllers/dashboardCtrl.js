'use strict';

var format = require('../../util/format');
var util = require('../../util/util');

module.exports = function($scope, $rootScope, $state, $http, $timeout, toastr, cfpLoadingBar) {

	console.log("Navigated to dashboard.");

	/************ Globals *************/

    
	/*********** Transitions ***********/


	/*************** ONLOAD *******************/


};
