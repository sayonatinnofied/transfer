'use strict';

var format = require('../../util/format');
var util = require('../../util/util');

module.exports = function ($scope, $rootScope, $state, $http, $timeout, toastr, cfpLoadingBar, $uibModal, $document, $log) {
    console.log("Navigated to exception history.");

    // Root state save
    $scope.searchExceptionHistory = $rootScope.exceptionHistory.searchExceptionHistory;
    $scope.exceptions = $rootScope.exceptionHistory.exceptions;
    $scope.config = $rootScope.exceptionHistory.config;

    // Locals
    $scope.ErrorMsgCollection = angular.copy(format.ErrorMsgCollection);
    $scope.searchOpen = true;
    $scope.exceptionItems = null;
    $scope.interfaceId = null;
    $scope.emptyText = "No items to show";

    $scope.freshHeader = {};

    $scope.isValidForm = false;

    /******************** Date Config *********************/

    $scope.startDate = {
        minDate: null,
        maxDate: null
    };

    $scope.endDate = {
        minDate: null,
        maxDate: null
    };

    $scope.open = function (op) {
        switch (op) {
            case 1:
                $scope.status.startDate = true;
                break;
            case 2:
                $scope.status.endDate = true;
                break;
            default:
                break;
        }
    };

    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.format = 'yyyy-MM-dd';

    $scope.status = {
        startDate: false,
        endDate: false
    };

    /*********************** Pagination **********************/

    $scope.itemsPerPage = 20;
    $scope.maxSize = 5;

    /********************** Functions ************************/

    $scope.makeExceptionHTTPRequest = function (params, callback) {
        var req = angular.copy($rootScope.urlConfig.exceptionHistoryRequest);
        req.params = params;
        $rootScope.spinner.on();
        $http(req).then(function (res) {
            $scope.ErrorMsgCollection = res.data;
            if (params.Page == undefined) {
                $scope.config.totalExceptionItems = $scope.ErrorMsgCollection.NoOfPages * $scope.itemsPerPage;
            }
            angular.forEach($scope.ErrorMsgCollection.ErrorMsgRequest, function (value, key) {
                var obj = angular.extend({}, value.ErrorMsgHeader, value.ErrorMessageDesc);
                $scope.exceptions.push(obj);
            });
            toastr.success("Page " + $scope.config.currentExceptionPage + " exception records fetched.");
            console.log(res, params, $scope.config, $scope.exceptions);
            callback();
        }, function (res) {
            console.log(res);
            if (res.status == -1) {
                toastr.error("Error Connection Timeout");
            } else {
                toastr.error(res.data.message);
            }
            if ($scope.config.currentExceptionPage = 1) {
                $scope.config.currentExceptionPage = 0;
            }
            if (params.Page == undefined) {
                $scope.config.totalExceptionItems = 0;
            }
            $rootScope.spinner.off();
        });
    }

    $scope.advanceSearch = function () {
        console.log($scope.config.checked);
        $scope.searchExceptionHistory.ErrorTimeStampTo = undefined;
        $scope.searchExceptionHistory.ErrorTimeStampFrom = undefined;
        $scope.$broadcast('start-date-changed');
        $scope.$broadcast('end-date-changed');
    };

    $scope.isValidReq = function(isFormValid){

        if($scope.config.checked) {
           $scope.isValidForm = ($scope.searchExceptionHistory.InterfaceID || $scope.searchExceptionHistory.TransactionID) && $scope.searchExceptionHistory.ErrorTimeStampTo && $scope.searchExceptionHistory.ErrorTimeStampFrom  ? true : false;
        } else {
           $scope.isValidForm = $scope.searchExceptionHistory.InterfaceID || $scope.searchExceptionHistory.TransactionID ? true : false;
        }
        console.log(isFormValid, $scope.isValidForm);
    }

    $scope.getExceptionHistory = function (onEvent) {

        function onSuccess() {
            $scope.config.onSearch = true;
            $scope.interfaceId = $scope.searchExceptionHistory.InterfaceID;
            $rootScope.spinner.off();
        }

        if (onEvent) {
            $scope.getAllData();
            $scope.searchExceptionHistory.Page = undefined;
            $scope.config.currentExceptionPage = 1;
        } else {
            $scope.searchExceptionHistory.Page = $scope.config.currentExceptionPage;
        }
        $rootScope.exceptionHistory.exceptions = [];
        $scope.exceptions = $rootScope.exceptionHistory.exceptions;

        $scope.makeExceptionHTTPRequest($scope.searchExceptionHistory, onSuccess);

    }

    $scope.getExceptionDetails = function (exception) {
        $scope.open('lg', 'body', exception);
    };

    /* Bindable Datepicker functions -----------------------------------------------*/

    $scope.endDateBeforeRender = endDateBeforeRender
    $scope.endDateOnSetTime = endDateOnSetTime
    $scope.startDateBeforeRender = startDateBeforeRender
    $scope.startDateOnSetTime = startDateOnSetTime

    function startDateOnSetTime() {
        $scope.$broadcast('start-date-changed');
    }

    function endDateOnSetTime() {
        $scope.$broadcast('end-date-changed');
    }

    function startDateBeforeRender($dates) {
        if ($scope.searchExceptionHistory.ErrorTimeStampTo) {
            var activeDate = moment($scope.searchExceptionHistory.ErrorTimeStampTo);

            $dates.filter(function (date) {
                return date.localDateValue() >= activeDate.valueOf()
            }).forEach(function (date) {
                date.selectable = false;
            })
        }
    }

    function endDateBeforeRender($view, $dates) {
        if ($scope.searchExceptionHistory.ErrorTimeStampFrom) {
            var activeDate = moment($scope.searchExceptionHistory.ErrorTimeStampFrom).subtract(1, $view).add(1, 'minute');

            $dates.filter(function (date) {
                return date.localDateValue() <= activeDate.valueOf()
            }).forEach(function (date) {
                date.selectable = false;
            })
        }
    }

    /*********************** Table Check Action ******************/

    $scope.changeSelectAll = function (isAllSelected) {
        for (var index in $scope.exceptionItems) {
            $scope.exceptionItems[index].checked = isAllSelected;
        }
    }

    $scope.changeSelectOne = function (exception, index) {
        console.log(exception.checked);
    }

    $scope.isSelectEnabled = function (arrayFrom) {
        var bool = false;
        for (var index in arrayFrom) {
            if (arrayFrom[index].checked) {
                bool = true;
                break;
            }
        }
        return bool;
    };

    $scope.getSelectedData = function (arrayFrom) {
        var data = [];
        if ($scope.isSelectEnabled(arrayFrom)) {
            for (var index in arrayFrom) {
                var tmp = angular.copy(arrayFrom[index]);
                tmp.BusinessKeys = JSON.stringify(tmp.BusinessKeys);
                if (tmp.checked) {
                    delete tmp.checked;
                    data.push(tmp);
                }
            }
        } else {
            for (var index in arrayFrom) {
                var tmp = angular.copy(arrayFrom[index]);
                tmp.BusinessKeys = JSON.stringify(tmp.BusinessKeys);
                delete tmp.checked;
                data.push(tmp);
            }
        }
        console.log(data);
        return data;
    }

    /*********************** CSV Config **************************/

    $scope.exportData = function () {

    }

    $scope.csvConfig = {
        getHeader: function () {
            return Object.keys($scope.freshHeader);
        },
        getData: function () {
            return $scope.getSelectedData($scope.exceptionItems);
        },
        seperator: ',',
        lazyLoad: true,
        getFileName: function () {
            return 'ExH_' + $scope.interfaceId + '_' + util.formatDate(new Date());
        }
    }

       /*********************** CSV All Config **************************/

    $scope.getAllData = function(){
        var params = angular.copy($scope.searchExceptionHistory);
        params.Page = undefined;
        params.AllPages = true;
        $scope.allData = [];
        var req = angular.copy($rootScope.urlConfig.exceptionHistoryRequest);
        req.params = params;
        $rootScope.spinner.on();
        $http(req).then(function (res) {
            var responseData = res.data;
            angular.forEach(responseData.ErrorMsgRequest, function (value, key) {
                var obj = angular.extend({}, value.ErrorMsgHeader, value.ErrorMessageDesc);
                obj.BusinessKeys = JSON.stringify(obj.BusinessKeys);
                $scope.allData.push(obj);
            });
            $scope.freshHeader = angular.copy($scope.allData[0]);
            $rootScope.spinner.off();
        }, function (res) {
            if (res.status == -1) {
                console.log("Error Connection Timeout");
            } else {
                console.log(res.data.message);
            }
            $rootScope.spinner.off();
        });
    };

    $scope.csvAllConfig = {
        getHeader: function () {
            return Object.keys($scope.freshHeader);
        },
        getData: function () {
            return $scope.allData;
        },
        seperator: ',',
        lazyLoad: true,
        getFileName: function () {
            return 'LoH_' + $scope.interfaceId + '_' + util.formatDate(new Date());
        }
    }

    /********************** Sort Config ************************/
    $scope.sortConfig = {
        propertyName: '',
        reverse: false,
        setPropertyName: function (value) {
            this.propertyName = value;
        }
    }

    /********************* Modal ******************************/
    $scope.open = function (size, parentSelector, exception) {
        var parentElem = parentSelector ?
            angular.element($document[0].querySelector(parentSelector)) : undefined;

        var modalInstance = $uibModal.open({
            templateUrl: 'app/templates/exceptiondetails.html',
            controller: 'exceptionDetailsCtrl',
            size: size,
            appendTo: parentElem,
            resolve: {
                exception: function () {
                    return exception;
                }
            }
        });

        modalInstance.result.then(function () {
            $log.info('Modal dismissed at: ' + new Date());
        }, function () {
            $log.info('Modal dismissed at: ' + new Date());
        });
    };

    /********************** Watchers **************************/
    $scope.$watch('config.currentExceptionPage', function (newValue, oldValue) {
        console.log(oldValue, newValue);
        if (oldValue > 0 && newValue >= 1) {
            $scope.getExceptionHistory();
        }
    })
};