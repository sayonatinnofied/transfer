'use strict';

var fs = require('fs');

var util = require('../../util/util');

module.exports = function($stateProvider, $locationProvider, $urlRouterProvider) {

    $stateProvider
        .state('login', {
            url: '/login',
            template: fs.readFileSync(__dirname + '/../../templates/login.html'),
            controller: 'loginCtrl'
        })
        .state('clebase', {
            url: '/clebase',
            template: fs.readFileSync(__dirname + '/../../templates/clebase.html'),
            controller: 'clebaseCtrl'
        })
        /******************** CLE BASE Routes *************************/
        .state('clebase.dashboard', {
            url: '/dashboard',
            views: {
                'content': {
                    template: fs.readFileSync(__dirname + '/../../templates/dashboard.html'),
                    controller: 'dashboardCtrl'
                }
            }
        }).state('clebase.loghistory', {
            url: '/loghistory',
            views: {
                'content': {
                    template: fs.readFileSync(__dirname + '/../../templates/loghistory.html'),
                    controller: 'logHistoryCtrl'
                }
            }
        }).state('clebase.exceptionhistory', {
            url: '/exceptionhistory',
            views: {
                'content': {
                    template: fs.readFileSync(__dirname + '/../../templates/exceptionhistory.html'),
                    controller: 'exceptionHistoryCtrl'
                }       
            }
        }).state('clebase.registerinterface', {
            url: '/registerinterface',
            views: {
                'content': {
                    template: fs.readFileSync(__dirname + '/../../templates/registerinterface.html'),
                    controller: 'configurationCtrl'
                }
            }
        }).state('clebase.configureinterface', {
            url: '/configureinterface',
            views: {
                'content': {
                    template: fs.readFileSync(__dirname + '/../../templates/configureinterface.html'),
                    controller: 'configurationCtrl'
                }
            }
        }).state('clebase.updateinterface', {
            url: '/updateinterface',
            views: {
                'content': {
                    template: fs.readFileSync(__dirname + '/../../templates/updateinterface.html'),
                    controller: 'configurationCtrl'
                }
            }
        });
        

    $urlRouterProvider.otherwise(function($injector,$location) {
        var $state = $injector.get('$state');
        var path = $location.$$path;
        // if(!util.getLocalStorage('login'))
            $state.go('login');
   
    });  
};
