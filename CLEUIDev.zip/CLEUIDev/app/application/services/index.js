'use strict';

var Service = angular.module('app.service', [])
    .service('UserService',
        function() {
            this.data = "";
            this.count = "";
        }
    );

module.exports = Service;
