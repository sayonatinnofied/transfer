'use strict';

module.exports = {

	/************************** HTTP Request ***************************/
	exceptionHistoryRequest: {
		url: 'http://localhost:8091/cleerrorhandler',
		method: 'GET',
		params: {
			TransactionId: '',
			InterfaceID: '',
			ErrorTimeStampFrom: '',
			ErrorTimeStampTo: '',
			Page: ''
		},
		responseType: 'json'
	},
	logHistoryRequest: {
		url: 'http://localhost:8091/cleloghandler',
		method: 'GET',
		params: {
			TransactionID: '',
			InterfaceID: '',
			LogTimeStampFrom: '',
			LogTimeStampTo: '',
			Page: ''
		},
		responseType: 'json'
	},

	configureInterfaceRequest: {
		url: 'http://PC301691.cts.com:8078/cleinterfaceconfig',
		method: 'POST',
		headers: {
			'Content-Type': 'application/json'
		},
		data: '',
		responseType: 'json'
	},

	registerInterfaceRequest: {
		url: 'http://PC301691.cts.com:8078/cleexceptionconfig',
		method: 'POST',
		headers: {
			'Content-Type': 'application/json'
		},
		data: '',
		responseType: 'json'
	},

	configurationResponse: {
		cleExceptionConfigOutput: true
	},

	configurations: {
		exception: {
			INTERFACE_ID: '',
			cleExceptionError: [{
				EXCEPTION_CODE: '',
				EXCEPTION_DESC: '',
				EXCEPTION_CATEGORY: ''
			}]
		},
		log: {
			INTERFACE_ID: '',
			INTERFACE_TYPE: '',
			INTERFACE_DOMAIN: ''
		},
		cleExceptionErrorType: {
			EXCEPTION_CODE: '',
			EXCEPTION_DESC: '',
			EXCEPTION_CATEGORY: ''
		}
	},

	/************************* Internal Object *****************************/
	user: {
		CustomerName: '',
		Designation: '',
		Email: 'admin@cts.com',
		Password: 'admin'
	},
	searchLogHistory: {
		TransactionID: undefined,
		InterfaceID: undefined,
		LogTimeStampFrom: undefined,
		LogTimeStampTo: undefined,
		Page: undefined,
		AllPages: undefined
	},
	searchExceptionHistory: {
		TransactionId: undefined,
		InterfaceID: undefined,
		ErrorTimeStampFrom: undefined,
		ErrorTimeStampTo: undefined,
		Page: undefined,
		AllPages: undefined
	},
	logHistory: {
		searchLogHistory: {},
		logs: [],
		config: {
		}
	},
	exceptionHistory: {
		searchExceptionHistory: {},
		exceptions: [],
		config: {
		}
	},
	logConfig: {
		onSearch: false,
		checked: false,
		totalLogItems: 0,
		currentLogPage: 0
	},
	exceptionConfig: {
		onSearch: false,
		checked: false,
		totalExceptionItems: 0,
		currentExceptionPage: 0
	},
	logs: [],
	exceptions: [],

	/********************************** Log Messages ************************************/
	LogMsgCollectionArray: [],
	LogMsgCollection: {
		LogMsgRequest: [],
		NoOfPages: 0
	},
	LogMsgRequest: {
		LogMsgHeader: {},
		LogMsgDescription: {}
	},
	LogMsgHeader: {
		InterfaceId: '',
		TransactionType: 'LOG',
		TransactionDomain: 'WINx64'
	},
	LogMsgDescription: {
		LogLevel: 'INFO',
		GeneralLogMsg: '',
		Status: '',
		ProcessName: '',
		TransactionID: '',
		LogCorrelationID: '',
		OperationName: '',
		LogTimeStamp: '',
		Payload: '',
		BusinessKeys: ''
	},

	/********************************** Exception Messages ************************************/
	ErrorMsgCollection: {
		ErrorMsgRequest: [],
		NoOfPages: 0
	},
	ErrorMsgRequest: {
		ErrorMsgHeader: {},
		ErrorMsgDesc: {}
	},
	ErrorMsgHeader: {
		InterfaceID: '',
		TransactionType: 'LOG',
		TransactionDomain: 'WINx64'
	},
	ErrorMsgDesc: {
		ErrorCategory: '',
		ErrorSeverity: 'INFO',
		ErrorCode: '',
		ErrorDescription: '',
		ErrorStack: '',
		ProcessStack: '',
		TransactionID: '',
		ProcessName: '',
		CorrelationID: '',
		OperationName: '',
		ErrorTimeStamp: '',
		Payload: ''
	},

	/******************************* Error Messages *************************************/
	error: {
		statusCode: '',
		message: ''
	}
};