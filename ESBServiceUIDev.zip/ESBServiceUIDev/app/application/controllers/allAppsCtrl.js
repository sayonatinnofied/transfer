'use strict';
var fs = require('fs');
var format = require('../../util/format');
var util = require('../../util/util');

module.exports = function ($scope, $rootScope, $state, $http, $timeout, toastr, cfpLoadingBar, ngDialog) {
    console.log("Navigated to all apps.");

    $scope.environment = {};
    $scope.application = {};
    $scope.applicationDetails = [];
    $scope.applicationDetail = {};

    $scope.search = {
        environmentId: ''
    };

    $scope.environmentData = {
        environments: []
    };

    /********************** Sort Config ************************/
    $scope.sortConfig = {
        propertyName: '',
        reverse: false,
        setPropertyName: function (value) {
            this.propertyName = value;
        }
    }
    
    /******************************************************** */

    $scope.resetSearch = function (type) {

        switch (type) {
            case 'all': {
                $scope.environment = {};
                $scope.application = {};

                $scope.search = {
                    environmentId: ''
                };

                // $scope.environmentData = {
                //     environments: []
                // };
                break;
            }
            default: {
                console.log('Doesnt match any!');
                break;
            }
        }

    };

    $scope.selectEnvironment = function (environmentId) {
        console.log($scope.search.environmentId);
        $scope.environment = $scope.environmentData.environments.filter(function (environment) { return environment.environmentId === $scope.search.environmentId; })[0];
        $scope.applicationDetails = [];
        console.log($scope.environment);
    }

    $scope.getApplicationDetails = function () {

        var req = angular.copy(format.getApplicationDetailsRequest);
        var reqUrl = angular.copy($rootScope.urlConfig.getApplicationDetailsUrl);

        req.url = reqUrl;
        req.params.domain = $scope.environment.domain;
        req.params.filter = undefined;
        req.params.host = $scope.environment.hostUrl;
        req.params.port = $scope.environment.hostPort;
        console.log(req);

        $rootScope.spinner.on();
        $http(req).then(function (res) {
            console.log(res.data);
            $scope.applicationDetails = res.data;
            $rootScope.spinner.off();
        }, function (res) {
            console.log(res);
            if (res.status == -1) {
                toastr.error("Error Connection Timeout");
            } else {
                toastr.error('Failed to fetch application details');
            }
            $rootScope.spinner.off();
        });
    };

    $scope.checkApplicationDetails = function(appName) {
        var params = {
            environment:$scope.environment,
            applicationName:appName
        };
        console.log(params);
        $state.go('base.serviceinformation', params);
    };

    /************* Callee ******************/
    $rootScope.getAllEnvironments($scope.environmentData);


}; 