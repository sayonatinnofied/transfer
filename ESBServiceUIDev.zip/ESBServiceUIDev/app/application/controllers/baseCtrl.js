'use strict';

var format = require('../../util/format');
var util = require('../../util/util');

module.exports = function ($scope, $rootScope, $state, $http, $timeout, toastr, cfpLoadingBar) {
    console.log("Navigated to base.");

    if (!util.getLocalStorage('login') || !$rootScope.user) {
        $state.go('login');
    }

    $scope.user = $rootScope.user;
    $rootScope.urlConfig = null;

    /********************** Root Scope Functions *******************/

    $rootScope.getAllEnvironments = function (data) {
        var url = $rootScope.urlConfig.environmentUrl;
        var req = angular.copy(format.getEnvironmentRequest);
        req.url = url;
        $rootScope.spinner.on();
        $http(req).then(function (res) {
            console.log(res.data);
            data.environments = res.data;
            $rootScope.spinner.off();
        }, function (res) {
            console.log(res);
            if (res.status == -1) {
                toastr.error("Error Connection Timeout");
            } else {
                if (res.status == 404) {
                    data.environments = [];
                }
                toastr.error('Failed to fetch environments');
            }
            $rootScope.spinner.off();
        });
    }

    $rootScope.getAllApplications = function (data) {
        var url = $rootScope.urlConfig.applicationUrl;
        var req = angular.copy(format.getApplicationRequest);
        req.url = url;
        req.params.id = data.environmentId;
        $rootScope.spinner.on();
        $http(req).then(function (res) {
            console.log(res.data);
            data.applications = res.data;
            $rootScope.spinner.off();
        }, function (res) {
            console.log(res);
            if (res.status == -1) {
                toastr.error("Error Connection Timeout");
            } else {
                if (res.status == 404) {
                    data.applications = [];
                }
                toastr.error('Failed to fetch applications');
            }
            $rootScope.spinner.off();
        });
    }


    /********************** Transitions **********************/

    $scope.goBase = function () {
        $state.go('base');
    }

    $scope.goDashboard = function () {
        $state.go('base.dashboard');
    }

    $scope.goServiceInformation = function () {
        $state.go('base.serviceinformation');
    }

    $scope.goConfigureEnvironments = function () {
        $state.go('base.configureenvironments');
    }

    $scope.goConfigureApplications = function () {
        $state.go('base.configureapplications');
    }

    $scope.goAllApplications = function () {
        $state.go('base.allapps');
    }

    /********************** Functions ******************************/

    $scope.logout = function () {
        util.deleteLocalStorage('login');
        $state.go('login');
    }

    $rootScope.spinner.on();
    $http.get('urls.json').then(function (res) {
        $rootScope.urlConfig = res.data;
        console.log($rootScope.urlConfig);
        $rootScope.spinner.off();
    });
};