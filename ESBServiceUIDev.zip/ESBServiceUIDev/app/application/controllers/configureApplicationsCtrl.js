'use strict';

var format = require('../../util/format');
var util = require('../../util/util');

module.exports = function ($scope, $rootScope, $state, $http, $timeout, $interval, toastr, cfpLoadingBar, $stateParams, $uibModal, $document, $log, ngDialog) {

    console.log("Navigated to configure application.");

    // Locals
    $scope.addApplicationOpen = false;
    $scope.configureApplicationOpen = true;

    $scope.emptyText = "No items to show";
    $scope.environmentData = {
        environments: []
    };

    var operationAdd = {
        type: "Add",
        btnAction: 'Add',
        data: {}
    };
    var operationUpdate = {
        type: "Update",
        btnAction: 'Update',
        data: {}
    };

    $scope.search = {
        environmentId: '',
        environment: {},
        applications: []
    };

    $scope.applicationItems = [];

    /*********************** Pagination **********************/

    $scope.paginationConfig = {
        totalItems: $scope.applicationItems.length,
        currentPage: 1,
        itemsPerPage: 20,
        maxSize: 5
    };

    /********************** Functions ************************/
    $scope.resetSearch = function () {
        $scope.search = {
            environmentId: '',
            environment: {},
            applications: []
        }
    };

    $scope.filterApplication = function () {

    };

    $scope.addApplication = function () {
        $scope.open('lg', 'body', operationAdd);
    };

    $scope.updateApplication = function (application) {
        operationUpdate.data = angular.copy(application);
        $scope.open('lg', 'body', operationUpdate);
    };

    $scope.deleteApplication = function (applicationId) {

        function deleteApi() {
            console.log("Delete in progress");
            var url = $rootScope.urlConfig.applicationUrl;
            var req = angular.copy(format.deleteApplicationRequest);
            req.url = url;
            req.params.id = applicationId;
            console.log(req);
            $rootScope.spinner.on();
            $http(req).then(function (res) {
                console.log(res.data);
                toastr.success('Application deleted!');
                $rootScope.spinner.off();
                $rootScope.getAllApplications($scope.search);
            }, function (res) {
                console.log(res);
                if (res.status == -1) {
                    toastr.error("Error Connection Timeout");
                } else {
                    toastr.error('Failed to delete application');
                }
                $rootScope.spinner.off();
            });
        }

        $scope.type = "application";
        ngDialog.openConfirm({
            template: 'app/templates/popup.html',
            scope: $scope
        }).then(function (value) {
            console.log('Modal promise resolved. Value: ', value);
            if (value) {
                deleteApi();
            }
        }, function (reason) {
            console.log('Modal promise rejected. Reason: ', reason);
        });

    };

    $scope.getApplications = function () {
        $scope.search.environment = $scope.environmentData.environments.filter(function (environment) {
            return environment.environmentId === $scope.search.environmentId;
        })[0];
        $rootScope.getAllApplications($scope.search);
    };

    /********************** Sort Config ************************/
    $scope.sortConfig = {
        propertyName: '',
        reverse: false,
        setPropertyName: function (value) {
            this.propertyName = value;
        }
    }

    /********************* Modal ******************************/
    $scope.open = function (size, parentSelector, operation) {
        var parentElem = parentSelector ?
            angular.element($document[0].querySelector(parentSelector)) : undefined;

        var modalInstance = $uibModal.open({
            templateUrl: 'app/templates/upsertapplication.html',
            controller: 'upsertApplicationCtrl',
            size: size,
            appendTo: parentElem,
            resolve: {
                operation: function () {
                    return operation;
                }
            }
        });

        modalInstance.result.then(function (envId) {
            $log.info('Modal dismissed at: ' + new Date());
            console.log(envId);
            if (envId) {
                $scope.search = {
                    environmentId: envId,
                    environment: {},
                    applications: []
                };
                $rootScope.getAllApplications($scope.search);
            }
        }, function () {
            $log.info('Modal dismissed at: ' + new Date());
        });
    };

    /******************** Calee ****************/

    $rootScope.getAllEnvironments($scope.environmentData);

};