'use strict';

var format = require('../../util/format');
var util = require('../../util/util');

module.exports = function ($scope, $rootScope, $state, $http, $timeout, toastr, cfpLoadingBar, $uibModal, $document, $log, ngDialog) {
    console.log("Navigated to configure environment.");

    // Locals
    $scope.addEnvironmentOpen = false;
    $scope.emptyText = "No items to show";
    $scope.environmentData = {
        environments: []
    };

    var operationAdd = {
        type: "Add",
        btnAction: 'Add',
        data: {}
    };
    var operationUpdate = {
        type: "Update",
        btnAction: 'Update',
        data: {}
    };

    $scope.environmentItems = [];

    /*********************** Pagination **********************/

    $scope.paginationConfig = {
        totalItems: $scope.environmentItems.length,
        currentPage: 1,
        itemsPerPage: 20,
        maxSize: 5
    };

    /********************** Functions ************************/

    $scope.filterEnvironments = function () {

    };

    $scope.addEnvironment = function () {
        $scope.open('lg', 'body', operationAdd);
    };

    $scope.updateEnvironment = function (application) {
        operationUpdate.data = angular.copy(application);
        $scope.open('lg', 'body', operationUpdate);
    };

    $scope.deleteEnvironment = function (environmentId) {
        function deleteApi() {
            console.log("Delete in progress");
            var url = $rootScope.urlConfig.environmentUrl;
            var req = angular.copy(format.deleteEnvironmentRequest);
            req.url = url;
            req.params.id = environmentId;
            console.log(req);
            $rootScope.spinner.on();
            $http(req).then(function (res) {
                console.log(res.data);
                toastr.success('Environment deleted!');
                $rootScope.spinner.off();
                $rootScope.getAllEnvironments($scope.environmentData);
            }, function (res) {
                console.log(res);
                if (res.status == -1) {
                    toastr.error("Error Connection Timeout");
                } else {
                    toastr.error('Failed to delete environment');
                }
                $rootScope.spinner.off();
            });
        }

        $scope.type = "environment";
        ngDialog.openConfirm({
            template: 'app/templates/popup.html',
            scope: $scope
        }).then(function (value) {
            console.log('Modal promise resolved. Value: ', value);
            if (value) {
                deleteApi();
            }
        }, function (reason) {
            console.log('Modal promise rejected. Reason: ', reason);
        });

    }

    /********************** Sort Config ************************/
    $scope.sortConfig = {
        propertyName: '',
        reverse: false,
        setPropertyName: function (value) {
            this.propertyName = value;
        }
    }

    /********************* Modal ******************************/
    $scope.open = function (size, parentSelector, operation) {
        var parentElem = parentSelector ?
            angular.element($document[0].querySelector(parentSelector)) : undefined;

        var modalInstance = $uibModal.open({
            templateUrl: 'app/templates/upsertenvironment.html',
            controller: 'upsertEnvironmentCtrl',
            size: size,
            appendTo: parentElem,
            resolve: {
                operation: function () {
                    return operation;
                }
            }
        });

        modalInstance.result.then(function () {
            $log.info('Modal dismissed at: ' + new Date());
            $rootScope.getAllEnvironments($scope.environmentData);
        }, function () {
            $log.info('Modal dismissed at: ' + new Date());
        });
    };

    /******************** Calee ****************/

    $rootScope.getAllEnvironments($scope.environmentData);
};