'use strict';
var fs = require('fs');
var format = require('../../util/format');
var util = require('../../util/util');

module.exports = function ($scope, $stateParams, $rootScope, $state, $http, $timeout, toastr, cfpLoadingBar, ngDialog) {
    console.log("Navigated to service information.");

    $scope.environment = {};
    $scope.application = {};
    $scope.applicationDetails = [];
    $scope.applicationDetail = {};

    $scope.search = {
        environmentId: '',
        applicationId: '',
        applications: []
    };

    $scope.environmentData = {
        environments: []
    };

    /********************** Sort Config ************************/
    $scope.sortConfig = {
        propertyName: '',
        reverse: false,
        setPropertyName: function (value) {
            this.propertyName = value;
        }
    }

    /******************************************************** */

    $scope.resetSearch = function (type) {

        switch (type) {
            case 'all': {
                $scope.environment = {};
                $scope.application = {};

                $scope.search = {
                    environmentId: '',
                    applicationId: '',
                    applications: []
                };

                // $scope.environmentData = {
                //     environments: []
                // };
                break;
            }
            case 'applicationId': {
                $scope.application = {};
                $scope.search.applicationId = '';
                break;
            }
            default: {
                console.log('Doesnt match any!');
                break;
            }
        }

    };

    $scope.selectEnvironment = function (environmentId) {
        console.log($scope.search.environmentId);
        $scope.environment = $scope.environmentData.environments.filter(function (environment) { return environment.environmentId === $scope.search.environmentId; })[0];
        $scope.resetSearch('applicationId');
        $rootScope.getAllApplications($scope.search);
        console.log($scope.environment);
    }

    $scope.selectApplication = function (applicationId) {
        console.log($scope.search.applicationId);
        $scope.application = $scope.search.applications.filter(function (application) { return application.applicationId === $scope.search.applicationId; })[0];
        console.log($scope.application);
    }

    $scope.getApplicationDetails = function () {

        var req = angular.copy(format.getApplicationDetailsRequest);
        var reqUrl = angular.copy($rootScope.urlConfig.getApplicationDetailsUrl);

        req.url = reqUrl;
        req.params.domain = $scope.environment.domain;
        req.params.filter = $scope.application.applicationName;
        req.params.host = $scope.environment.hostUrl;
        req.params.port = $scope.environment.hostPort;
        console.log(req);

        $rootScope.spinner.on();
        $http(req).then(function (res) {
            console.log(res.data);
            $scope.applicationDetails = res.data;
            $rootScope.spinner.off();
        }, function (res) {
            console.log(res);
            if (res.status == -1) {
                toastr.error("Error Connection Timeout");
            } else {
                toastr.error('Failed to fetch application details');
            }
            $rootScope.spinner.off();
        });
    };

    /************* Callee ******************/
    $rootScope.getAllEnvironments($scope.environmentData);

    /*********** Auto Call ***************/
    console.log($stateParams);
    if ($stateParams.applicationName) {
        $scope.environment = $stateParams.environment;
        $scope.application = {
            applicationId:'',
            applicationName:$stateParams.applicationName
        };
        $scope.getApplicationDetails();
    }

}; 