'use strict';
var fs = require('fs');
var format = require('../../util/format');
var util = require('../../util/util');

module.exports = function ($scope, $rootScope, $state, $stateParams, $http, $timeout, toastr, cfpLoadingBar, ngDialog, $uibModalInstance, operation) {
    console.log("Navigated to upsert application.", operation);

    $scope.operation = angular.copy(operation);
    $scope.application = angular.copy(format.application);

    var updateFlag = operation.type === 'Update';

    if (updateFlag) {
        $scope.application = angular.copy(operation.data);
    }

    $scope.environmentData = {
        environments: []
    };

    var reset = function () {
        $scope.environmentData = {
            environments: []
        };
        $scope.application = angular.copy(format.application);
    }

    $scope.close = function () {
        reset();
        $uibModalInstance.close();
    };

    $scope.cancel = function () {
        reset();
        $uibModalInstance.dismiss('cancel');
    };

    $scope.addApplication = function () {
        var url = $rootScope.urlConfig.applicationUrl;
        var req = angular.copy(format.postApplicationRequest);
        req.url = url;
        req.method = updateFlag ? 'PUT' : 'POST';

        var dataArr = [];
        dataArr.push($scope.application);
        req.data = updateFlag ? $scope.application : dataArr;

        $rootScope.spinner.on();
        $http(req).then(function (res) {
            console.log(res.data);
            updateFlag ? toastr.success('Application updated!') : toastr.success('Application added!');
            $rootScope.spinner.off();
            $uibModalInstance.close($scope.application.environmentId);
        }, function (res) {
            console.log(res);
            if (res.status == -1) {
                toastr.error("Error Connection Timeout");
            } else {
                updateFlag ? toastr.error('Failed to add application') : toastr.error('Failed to add application');
            }
            $rootScope.spinner.off();
        });
    }

    $rootScope.getAllEnvironments($scope.environmentData);

};