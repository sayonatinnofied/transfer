'use strict';
var fs = require('fs');
var format = require('../../util/format');
var util = require('../../util/util');

module.exports = function ($scope, $rootScope, $state, $stateParams, $http, $timeout, toastr, $uibModalInstance, cfpLoadingBar, ngDialog, operation) {
    console.log("Navigated to upsert environment.", operation);

    $scope.operation = angular.copy(operation);
    $scope.environment = angular.copy(format.environment);

    var updateFlag = operation.type === 'Update';

    if (updateFlag) {
        $scope.environment = angular.copy(operation.data);
    }

    var reset = function () {
        $scope.environment = angular.copy(format.environment);
    }

    $scope.close = function () {
        reset();
        $uibModalInstance.close();
    };

    $scope.cancel = function () {
        reset();
        $uibModalInstance.dismiss('cancel');
    };

    $scope.addEnvironment = function () {
        var url = $rootScope.urlConfig.environmentUrl;
        var req = angular.copy(format.postEnvironmentRequest);
        req.url = url;
        req.method = updateFlag ? 'PUT' : 'POST';

        var dataArr = [];
        dataArr.push($scope.environment);
        req.data = updateFlag ? $scope.environment : dataArr;

        console.log(req);
        $rootScope.spinner.on();
        $http(req).then(function (res) {
            console.log(res.data);
            updateFlag ? toastr.success('Environment updated!') : toastr.success('Environment added!');
            $rootScope.spinner.off();
            $uibModalInstance.close();
        }, function (res) {
            console.log(res);
            if (res.status == -1) {
                toastr.error("Error Connection Timeout");
            } else {
                updateFlag ? toastr.error('Failed to add environment') : toastr.error('Failed to add environment');
            }
            $rootScope.spinner.off();
        });
    };
};