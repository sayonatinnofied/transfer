'use strict';
var util = require('../../util/util');

var Directive = angular.module('app.directive', [])
    .directive('animate', function ($timeout) {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function ($scope, $element, attrs) {
                var isChecked = attrs.ngModel;
                var div = "." + attrs.animate;
                var resizeDiv = $(div);
                resizeDiv.css('display', 'none');
                $element.on('change', function () {
                    var resizeDiv = $(div);
                    var resolvedObj = util.detectIE() ? !util.resolveObject(isChecked, $scope) : util.resolveObject(isChecked, $scope);
                    console.log("IE Check box: ", isChecked, resolvedObj);
                    if (!resolvedObj) {
                        $(resizeDiv).slideUp(500, function () {
                            resizeDiv.css('display', 'none');
                        });
                    } else {
                        resizeDiv.css('display', 'none');
                        $(resizeDiv).slideDown(500, function () { });
                    }
                });
            }
        }
    })
    .directive('collapseBox', function ($timeout) {
        return {
            restrict: 'A',
            link: function ($scope, $element, attrs) {
                var scopeVar = attrs.scope;
                var div = "#" + attrs.collapse;

                function resize(onLoad) {
                    var resizeDiv = $(div);
                    if (!$scope[scopeVar]) {
                        if (onLoad) {
                            resizeDiv.css('display', 'none');
                        } else {
                            $(resizeDiv).slideUp(500, function () {
                                resizeDiv.css('display', 'none');
                            });
                        }
                    } else {
                        if (onLoad) {

                        } else {
                            resizeDiv.css('display', 'none');
                            $(resizeDiv).slideDown(500, function () { });
                        }
                    }
                }

                resize(true);

                $element.on('click', function () {
                    $scope.$apply(function () {
                        $scope[scopeVar] = !$scope[scopeVar];
                    });
                    // console.log(!$scope[scopeVar]);
                    resize();
                });
            }
        }
    })
    .directive('handleSort', function ($timeout) {
        return {
            restrict: 'A',
            link: function ($scope, $element, attrs) {

                var headings = $($element).children();
                $($element).addClass('handle-sort-wrapper');
                var scopeVar = attrs.sortConfig;
                // console.log(headings, scopeVar);
                angular.forEach(headings, function (heading, key) {
                    // console.log(key , ':' , $(heading));
                    if ($(heading).attr('property-name')) {
                        $(heading).on('click', function () {
                            $(headings).removeClass('active');
                            $(heading).addClass('active');
                            $scope[scopeVar].propertyName = $(heading).attr('property-name');
                            $scope[scopeVar].reverse = !$scope[scopeVar].reverse;
                            $scope.$apply();
                            // console.log('Clicked', $(heading).attr('property-name'), $scope[scopeVar].reverse);
                        });
                    }
                });
            }
        }
    })
    .directive('capitalize', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attrs, modelCtrl) {
                var capitalize = function (inputValue) {
                    if (inputValue == undefined) inputValue = '';
                    var capitalized = inputValue.toUpperCase();
                    if (capitalized !== inputValue) {
                        modelCtrl.$setViewValue(capitalized);
                        modelCtrl.$render();
                    }
                    return capitalized;
                }
                modelCtrl.$parsers.push(capitalize);
                capitalize(scope[attrs.ngModel]);
            }
        };
    })
    .directive("removeMe", function ($rootScope) {
        return {
            link: function (scope, element, attrs) {
                element.bind("click", function () {
                    element.remove();
                });
            }
        }
    })
    .directive('retypePassword', function () {
        return {
            require: 'ngModel',
            link: function (scope, elm, attrs, ctrl) {
                ctrl.$parsers.unshift(function (viewValue, $scope) {
                    var noMatch = viewValue != scope.registerForm.password.$viewValue
                    ctrl.$setValidity('noMatch', noMatch);
                })
            }
        }
    })
    .directive('retypePasswordChange', function () {
        return {
            require: 'ngModel',
            link: function (scope, elm, attrs, ctrl) {
                ctrl.$parsers.unshift(function (viewValue, $scope) {
                    var noMatch = false;
                    noMatch = viewValue != scope.changePasswordForm.password.$viewValue;
                    ctrl.$setValidity('noMatch', noMatch)
                })
            }
        }
    })
    .directive('integer', function () {
        return {
            require: 'ngModel',
            link: function (scope, ele, attr, ctrl) {
                ctrl.$parsers.unshift(function (viewValue) {
                    return parseInt(viewValue, 10);
                });
            }
        };
    })
    .directive('fadeIn', function ($timeout) {
        return {
            restrict: 'A',
            link: function ($scope, $element, attrs) {
                $element.on('load', function () {
                    $element.css('display', 'none');
                    $($element).fadeIn(1000, function () { });
                });
            }
        }
    }).directive('resize', function ($timeout) {
        return {
            restrict: 'A',
            link: function ($scope, $element, attrs) {
                var div = "." + attrs.resize;
                $element.on('change', function () {
                    var resizeDiv = $($element).find(div);
                    resizeDiv.css('display', 'none');
                    $(resizeDiv).slideDown(1000, function () { });
                });
            }
        }
    }).directive('resizeOnClick', function ($timeout) {
        return {
            restrict: 'A',
            link: function ($scope, $element, attrs) {
                var div = "." + attrs.resizeOnClick;
                $element.on('click', function () {
                    var resizeDiv = $(div);
                    $(resizeDiv).slideUp(1000, function () {
                        $scope.$apply(function () {
                            $scope.previewImage = '';
                        });
                    });
                });
            }
        }
    }).directive('animateScroll', function ($timeout) {
        return {
            restrict: 'A',
            link: function ($scope, $element, attrs) {
                var value = attrs.animateScroll ? attrs.animateScroll : 0;
                $('html, body').animate({
                    scrollTop: value
                }, 1000);
            }
        }
    }).directive('navigateSidebar', function ($rootScope, $location) {
        return {
            restrict: 'A',
            link: function ($scope, $element, attrs) {

                var subMenu = $($element).find('ul.treeview-menu');
                var listItem = $($element).children().first();

                if (subMenu.length) {
                    listItem.on('click', function () {
                        if ($element.hasClass('treeview')) {
                            $('ul.treeview-menu').removeClass('menu-open').slideUp(1000, function () { });
                        }
                        if ($(subMenu).is(':visible')) {
                            $(subMenu).removeClass('menu-open').slideUp(1000, function () { });
                        }
                        else {
                            $(subMenu).addClass('menu-open').slideDown(1000, function () { });
                        }
                    });
                }

                var activateSidebarMenuItems = function () {
                    var navTargetName = "";
                    var path = $location.$$path.substring($location.$$path.lastIndexOf('/'));

                    navTargetName = util.routes[path];

                    var value = attrs.navigateSidebar ? attrs.navigateSidebar : '';

                    if (navTargetName == value) {

                        $('li.treeview').removeClass('active');
                        $('ul.treeview-menu li').removeClass('active');

                        if ($element.hasClass('treeview')) {
                            $('ul.treeview-menu').removeClass('menu-open').slideUp(1000, function () { });
                            $element.toggleClass('active');
                        } else {
                            $element.toggleClass('active');
                            var treeviewMenu = $element.parent();
                            if (!$(treeviewMenu).hasClass('menu-open')) {
                                $('ul.treeview-menu').removeClass('menu-open').slideUp(1000, function () { });
                            }
                            $(treeviewMenu).addClass('menu-open').slideDown(1000, function () { });
                            var treeviewParent = treeviewMenu.parent();
                            treeviewParent.toggleClass('active');
                        }
                    }
                }

                var bool = true;

                $rootScope.$on('$locationChangeSuccess', function (event, newValue, oldValue) {
                    activateSidebarMenuItems();
                });

                if (bool) {
                    activateSidebarMenuItems();
                    bool = false;
                }
            }
        }
    }).directive('checkActive', function ($rootScope, $location) {
        return {
            restrict: 'A',
            link: function ($scope, $element, attrs) {
                $element.on('click', function () {
                    $('li.treeview-menu-item').removeClass('active');
                    $element.toggleClass('active');
                });
            }
        }
    }).directive('treasureOverlaySpinner', function ($animate) {
        return {
            templateUrl: '/template/treasure-overlay-spinner/treasure-overlay-spinner.html',
            scope: { active: '=' },
            transclude: true,
            restrict: 'E',
            link: function (scope, iElement) {
                scope.$watch('active', statusWatcher);
                function statusWatcher(active) {
                    $animate[active ? 'addClass' : 'removeClass'](iElement, 'treasure-overlay-spinner-active');
                }
            }
        };
    }).directive('preScroll', function ($timeout) {

        return {
            restrict: 'A',
            link: function ($scope, $element, attrs) {
                var scopeVar = attrs.scope;
                // console.log(attrs, scopeVar);
                function scrollToBottom() {
                    var elementId = '#' + attrs.id;
                    // console.log("Element: ", $(elementId), "ScrollHeight: ", $(elementId)[0].scrollHeight);
                    $(elementId).animate({
                        scrollTop: $(elementId)[0].scrollHeight
                    }, 1000);
                }

                $scope.$watch(scopeVar, function () {
                    scrollToBottom();
                });

            }
        }
    }).directive('scrollTo', function ($timeout) {

        return {
            restrict: 'A',
            link: function ($scope, $element, attrs) {
                // console.log(attrs);

                function scrollToDiv() {
                    var elementId = '#' + attrs.id;

                    $timeout(function () {
                        if ($(elementId).offset() != undefined) {
                            $('html,body').animate({
                                scrollTop: $(elementId).offset().top
                            }, 1000)
                        }
                    }, 200);
                }

                $scope.$watch(attrs.scope, function () {
                    if (util.resolveObject(attrs.scope, $scope)) {
                        scrollToDiv();
                    }
                });

            }
        }
    });

module.exports = Directive;
