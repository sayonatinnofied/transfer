'use strict';

var fs = require('fs');

var util = require('../../util/util');

module.exports = function ($stateProvider, $locationProvider, $urlRouterProvider) {

    $stateProvider
        .state('login', {
            url: '/login',
            template: fs.readFileSync(__dirname + '/../../templates/login.html'),
            controller: 'loginCtrl'
        })
        .state('base', {
            url: '/base',
            template: fs.readFileSync(__dirname + '/../../templates/base.html'),
            controller: 'baseCtrl'
        })
        /******************** CLE BASE Routes *************************/
        .state('base.dashboard', {
            url: '/dashboard',
            views: {
                'content': {
                    template: fs.readFileSync(__dirname + '/../../templates/dashboard.html'),
                    controller: 'dashboardCtrl'
                }
            }
        }).state('base.configureenvironments', {
            url: '/configureenvironments',
            views: {
                'content': {
                    template: fs.readFileSync(__dirname + '/../../templates/configureenvironments.html'),
                    controller: 'configureEnvironmentsCtrl'
                }
            }
        }).state('base.serviceinformation', {
            url: '/serviceinformation',
            views: {
                'content': {
                    template: fs.readFileSync(__dirname + '/../../templates/serviceinformation.html'),
                    controller: 'serviceInformationCtrl'
                }
            },
            params: {
                environment: {},
                applicationName: ""
            }
        }).state('base.configureapplications', {
            url: '/configureapplications',
            views: {
                'content': {
                    template: fs.readFileSync(__dirname + '/../../templates/configureapplications.html'),
                    controller: 'configureApplicationsCtrl'
                }
            }
        }).state('base.allapps', {
            url: '/allapps',
            views: {
                'content': {
                    template: fs.readFileSync(__dirname + '/../../templates/allapps.html'),
                    controller: 'allAppsCtrl'
                }
            }
        });


    $urlRouterProvider.otherwise(function ($injector, $location) {
        var $state = $injector.get('$state');
        var path = $location.$$path;
        // if(!util.getLocalStorage('login'))
        $state.go('login');

    });
};
