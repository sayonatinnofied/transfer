'use strict';

module.exports = {

	/************************** HTTP Request ***************************/
	getApplicationRequest: {
		url: 'http://localhost:2699/application',
		method: 'GET',
		headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json'
		},
		params: {
			id: ''
		}
	},
	postApplicationRequest: {
		url: 'http://localhost:2699/application',
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json'
		},
		data: ''
	},
	putApplicationRequest: {
		url: 'http://localhost:2699/application',
		method: 'PUT',
		headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json'
		},
		data: '',
		responseType: 'json'
	},
	deleteApplicationRequest: {
		url: 'http://localhost:2699/application',
		method: 'DELETE',
		headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json'
		},
		params: {
			id: ''
		}
	},

	getEnvironmentRequest: {
		url: 'http://localhost:2699/environment',
		method: 'GET',
		headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json'
		}
	},
	postEnvironmentRequest: {
		url: 'http://localhost:2699/environment',
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json'
		},
		data: ''
	},
	putEnvironmentRequest: {
		url: 'http://localhost:2699/environment',
		method: 'PUT',
		headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json'
		},
		data: ''
	},
	deleteEnvironmentRequest: {
		url: 'http://localhost:2699/environment',
		method: 'DELETE',
		headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json'
		},
		params: {
			id: ''
		}
	},

	getApplicationDetailsRequest: {
		url: 'http://10.125.2.201:2699/bwapiapplication',
		method: 'GET',
		timeout: 300000,
		headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json'
		},
		params: {
			domain: '',
			filter: '',
			status: true,
			host: '',
			port: ''
		}
	},

	/************************* Internal Object *****************************/

	application: {
		applicationId: '',
		applicationName: '',
		environmentId: ''
	},

	environment: {
		environmentId: '',
		environmentName: '',
		hostUrl: '',
		hostPort: '',
		domain: ''
	},

	user: {
		CustomerName: 'Anonymous',
		Designation: 'Administrator',
		Email: 'admin@cts.com',
		Password: 'admin'
	},

	/******************************* Error Messages *************************************/
	error: {
		statusCode: '',
		message: ''
	}
};