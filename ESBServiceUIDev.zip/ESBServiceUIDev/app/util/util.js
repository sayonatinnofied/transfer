'use strict';

module.exports = {
	routes: {
		'/dashboard': 'Dashboard',
		'/serviceinformation': 'Service Information',
		'/configureapplications': 'Configure Applications',
		'/configureenvironments': 'Configure Environments',
		'/allapps':'All Applications'
	},
	deleteCookie: function (name) {
		document.cookie = name + '=;expires=Thu, 01Jan 1970 00:00:01 GMT ; path=/';
	},
	setCookie: function (cname, cvalue) {
		document.cookie = cname + '=' + cvalue + '; path=/';
	},
	getCookie: function (cname) {
		var name = cname + '=',
			ca = document.cookie.split(';');
		for (var i = 0; i < ca.length; i++) {
			var c = ca[i];
			while (c.charAt(0) == ' ') c = c.substring(1);
			if (c.indexOf(name) != -1) {
				return c.substring(name.length, c.length);
			}
		}
		return '';
	},
	setLocalStorage: function (name, value) {
		if (value) {
			window.localStorage.setItem(name, value);
		}
	},
	getLocalStorage: function (cname) {
		if (window.localStorage[cname]) {
			return window.localStorage[cname];
		}
		return null;
	},
	deleteLocalStorage: function (cname) {
		if (window.localStorage[cname]) {
			window.localStorage.removeItem(cname);
		}
	},
	formatDate: function (date) {

		function pad(number, length) {
			var str = "" + number
			while (str.length < length) {
				str = '0' + str
			}
			return str
		}

		// console.log(date);
		var month = '' + (date.getMonth() + 1),
			day = '' + date.getDate(),
			year = date.getFullYear(),
			hour = pad(date.getHours(), 2),
			minute = pad(date.getMinutes(), 2),
			second = pad(date.getSeconds(), 2);

		var offset = new Date().getTimezoneOffset()
		offset = ((offset < 0 ? '+' : '-') + pad(parseInt(Math.abs(offset / 60)), 2) + ':' + pad(Math.abs(offset % 60), 2));

		if (month.length < 2) month = '0' + month;
		if (day.length < 2) day = '0' + day;

		return [year, month, day].join('-') + 'T' + [hour, minute, second].join(':') + offset;
		// 1999-05-31T13:20:00-05:00
	},
	parseDate: function (dateStr) {
		return new Date(dateStr.replace(/-/g, "/").replace(/T/g, " "));
	},
	mapFormat: function (source, destination) {
		for (var o in source) {
			for (var i in destination) {
				if (o == i) {
					destination[i] = angular.copy(source[o]);
					// if()
				}
			}
		}
	},
	resolveObject: function (path, obj) {
		return path.split('.').reduce(function (prev, curr) {
			return prev ? prev[curr] : undefined
		}, obj || self)
	},

	detectIE: function () {
		var ua = window.navigator.userAgent;

		// Test values; Uncomment to check result …

		// IE 10
		// ua = 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)';

		// IE 11
		// ua = 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko';

		// Edge 12 (Spartan)
		// ua = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 Edge/12.0';

		// Edge 13
		// ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586';

		var msie = ua.indexOf('MSIE ');
		if (msie > 0) {
			// IE 10 or older => return version number
			return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
		}

		var trident = ua.indexOf('Trident/');
		if (trident > 0) {
			// IE 11 => return version number
			var rv = ua.indexOf('rv:');
			return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
		}

		var edge = ua.indexOf('Edge/');
		if (edge > 0) {
			// Edge (IE 12+) => return version number
			return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
		}

		// other browser
		return false;
	}
};