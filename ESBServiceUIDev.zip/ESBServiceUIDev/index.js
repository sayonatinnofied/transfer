window.name = "NG_DEFER_BOOTSTRAP!";

window.xml2js = require('xml2js');

require('angular');
require('angular-animate');
require('angular-sanitize');
require('angular-toastr');
require('angular-ui-router');
require('angular-loading-bar');
require("jquery");
require("bootstrap");
global.moment = require('moment');
require("angular-ui-bootstrap");
require("angular-bootstrap-datetimepicker");
require("ng-csv");
require("ng-dialog");
require("ui-select");
require("app");

var App = require('./app/application/app.module');

angular.element().ready(function() {
    angular.resumeBootstrap([App['name']]);
});
