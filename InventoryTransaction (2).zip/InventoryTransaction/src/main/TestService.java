package main;

import java.rmi.RemoteException;

import pl.gov.csioz.zsmopl.ws.ObslugaKomunikatowProxy;
import pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladDostepnosci;
import pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladTworzeniaIdentyfikatoraKomunikatu;

public class TestService {

	public static void main(String[] args) throws BladTworzeniaIdentyfikatoraKomunikatu, BladDostepnosci, RemoteException {
		// TODO Auto-generated method stub
		ObslugaKomunikatowProxy proxyCall = new ObslugaKomunikatowProxy();
		proxyCall.zapiszKomunikatPD(null);
	}

}
