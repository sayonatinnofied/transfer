/**
 * IdentyfikatorPodmiotuRaportujacegoMT.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package pl.gov.csioz.zsmopl.mt;


/**
 * Identyfikator podmiotu raportujacego.
 */
public class IdentyfikatorPodmiotuRaportujacegoMT  implements java.io.Serializable {
    private java.lang.String idBiznesowy;

    private pl.gov.csioz.zsmopl.mt.RodzajPodmiotuRaportujacegoMT rodzajPodmiotuRaportujacego;

    public IdentyfikatorPodmiotuRaportujacegoMT() {
    }

    public IdentyfikatorPodmiotuRaportujacegoMT(
           java.lang.String idBiznesowy,
           pl.gov.csioz.zsmopl.mt.RodzajPodmiotuRaportujacegoMT rodzajPodmiotuRaportujacego) {
           this.idBiznesowy = idBiznesowy;
           this.rodzajPodmiotuRaportujacego = rodzajPodmiotuRaportujacego;
    }


    /**
     * Gets the idBiznesowy value for this IdentyfikatorPodmiotuRaportujacegoMT.
     * 
     * @return idBiznesowy
     */
    public java.lang.String getIdBiznesowy() {
        return idBiznesowy;
    }


    /**
     * Sets the idBiznesowy value for this IdentyfikatorPodmiotuRaportujacegoMT.
     * 
     * @param idBiznesowy
     */
    public void setIdBiznesowy(java.lang.String idBiznesowy) {
        this.idBiznesowy = idBiznesowy;
    }


    /**
     * Gets the rodzajPodmiotuRaportujacego value for this IdentyfikatorPodmiotuRaportujacegoMT.
     * 
     * @return rodzajPodmiotuRaportujacego
     */
    public pl.gov.csioz.zsmopl.mt.RodzajPodmiotuRaportujacegoMT getRodzajPodmiotuRaportujacego() {
        return rodzajPodmiotuRaportujacego;
    }


    /**
     * Sets the rodzajPodmiotuRaportujacego value for this IdentyfikatorPodmiotuRaportujacegoMT.
     * 
     * @param rodzajPodmiotuRaportujacego
     */
    public void setRodzajPodmiotuRaportujacego(pl.gov.csioz.zsmopl.mt.RodzajPodmiotuRaportujacegoMT rodzajPodmiotuRaportujacego) {
        this.rodzajPodmiotuRaportujacego = rodzajPodmiotuRaportujacego;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IdentyfikatorPodmiotuRaportujacegoMT)) return false;
        IdentyfikatorPodmiotuRaportujacegoMT other = (IdentyfikatorPodmiotuRaportujacegoMT) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.idBiznesowy==null && other.getIdBiznesowy()==null) || 
             (this.idBiznesowy!=null &&
              this.idBiznesowy.equals(other.getIdBiznesowy()))) &&
            ((this.rodzajPodmiotuRaportujacego==null && other.getRodzajPodmiotuRaportujacego()==null) || 
             (this.rodzajPodmiotuRaportujacego!=null &&
              this.rodzajPodmiotuRaportujacego.equals(other.getRodzajPodmiotuRaportujacego())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIdBiznesowy() != null) {
            _hashCode += getIdBiznesowy().hashCode();
        }
        if (getRodzajPodmiotuRaportujacego() != null) {
            _hashCode += getRodzajPodmiotuRaportujacego().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IdentyfikatorPodmiotuRaportujacegoMT.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "IdentyfikatorPodmiotuRaportujacegoMT"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idBiznesowy");
        elemField.setXmlName(new javax.xml.namespace.QName("", "idBiznesowy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rodzajPodmiotuRaportujacego");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rodzajPodmiotuRaportujacego"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "RodzajPodmiotuRaportujacegoMT"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
