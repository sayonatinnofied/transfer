/**
 * KomunikatMT.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package pl.gov.csioz.zsmopl.mt;


/**
 * Komunikat przesyłany przez podmioty raportujące.
 */
public class KomunikatMT  implements java.io.Serializable {
    private pl.gov.csioz.zsmopl.mt.IdentyfikatorKomunikatuMT idKomunikatPierwotny;

    private pl.gov.csioz.zsmopl.mt.IdentyfikatorPodmiotuRaportujacegoMT idPodmiotuRaportujacego;

    public KomunikatMT() {
    }

    public KomunikatMT(
           pl.gov.csioz.zsmopl.mt.IdentyfikatorKomunikatuMT idKomunikatPierwotny,
           pl.gov.csioz.zsmopl.mt.IdentyfikatorPodmiotuRaportujacegoMT idPodmiotuRaportujacego) {
           this.idKomunikatPierwotny = idKomunikatPierwotny;
           this.idPodmiotuRaportujacego = idPodmiotuRaportujacego;
    }


    /**
     * Gets the idKomunikatPierwotny value for this KomunikatMT.
     * 
     * @return idKomunikatPierwotny
     */
    public pl.gov.csioz.zsmopl.mt.IdentyfikatorKomunikatuMT getIdKomunikatPierwotny() {
        return idKomunikatPierwotny;
    }


    /**
     * Sets the idKomunikatPierwotny value for this KomunikatMT.
     * 
     * @param idKomunikatPierwotny
     */
    public void setIdKomunikatPierwotny(pl.gov.csioz.zsmopl.mt.IdentyfikatorKomunikatuMT idKomunikatPierwotny) {
        this.idKomunikatPierwotny = idKomunikatPierwotny;
    }


    /**
     * Gets the idPodmiotuRaportujacego value for this KomunikatMT.
     * 
     * @return idPodmiotuRaportujacego
     */
    public pl.gov.csioz.zsmopl.mt.IdentyfikatorPodmiotuRaportujacegoMT getIdPodmiotuRaportujacego() {
        return idPodmiotuRaportujacego;
    }


    /**
     * Sets the idPodmiotuRaportujacego value for this KomunikatMT.
     * 
     * @param idPodmiotuRaportujacego
     */
    public void setIdPodmiotuRaportujacego(pl.gov.csioz.zsmopl.mt.IdentyfikatorPodmiotuRaportujacegoMT idPodmiotuRaportujacego) {
        this.idPodmiotuRaportujacego = idPodmiotuRaportujacego;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof KomunikatMT)) return false;
        KomunikatMT other = (KomunikatMT) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.idKomunikatPierwotny==null && other.getIdKomunikatPierwotny()==null) || 
             (this.idKomunikatPierwotny!=null &&
              this.idKomunikatPierwotny.equals(other.getIdKomunikatPierwotny()))) &&
            ((this.idPodmiotuRaportujacego==null && other.getIdPodmiotuRaportujacego()==null) || 
             (this.idPodmiotuRaportujacego!=null &&
              this.idPodmiotuRaportujacego.equals(other.getIdPodmiotuRaportujacego())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIdKomunikatPierwotny() != null) {
            _hashCode += getIdKomunikatPierwotny().hashCode();
        }
        if (getIdPodmiotuRaportujacego() != null) {
            _hashCode += getIdPodmiotuRaportujacego().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(KomunikatMT.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "KomunikatMT"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idKomunikatPierwotny");
        elemField.setXmlName(new javax.xml.namespace.QName("", "idKomunikatPierwotny"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "IdentyfikatorKomunikatuMT"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idPodmiotuRaportujacego");
        elemField.setXmlName(new javax.xml.namespace.QName("", "idPodmiotuRaportujacego"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "IdentyfikatorPodmiotuRaportujacegoMT"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
