/**
 * KomunikatTransakcjaOSMT.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package pl.gov.csioz.zsmopl.mt;


/**
 * Transakcja obrotów i stanów.
 */
public class KomunikatTransakcjaOSMT  extends pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaMT  implements java.io.Serializable {
    private java.lang.String adresPodmDrugaStrona;

    private int czyTransakcjaJestKorekta;

    private java.util.Calendar dataDokKorygowanego;

    private java.lang.String idBiznesowyPodmDrugaStrona;

    private pl.gov.csioz.zsmopl.mt.IdentyfikatorMPDPodmiotuDrugaStronaMT idMPDPodmDrugaStrona;

    private java.lang.String krajPodmDrugaStrona;

    private java.lang.String nazwaPodmDrugaStrona;

    private java.lang.String nrDokKorygowanego;

    private java.lang.String[] nrDokSprzZakRefDokMag;

    private java.lang.String nrDokZewnetrznego;

    private java.lang.String nrDokZrodl;

    private java.lang.String nrERecepty;

    private pl.gov.csioz.zsmopl.mt.PodstawaWydaniaLekuMT podstawaWydaniaLeku;

    private java.lang.String przyczynaRoznicyInwentaryzacyjnej;

    private pl.gov.csioz.zsmopl.mt.RodzajDokZrodlSprzMT rodzajDokZrodlSprz;

    private java.lang.String rodzajPodmDrugaStrona;

    private pl.gov.csioz.zsmopl.mt.RodzajTransObrotuIStanuMT rodzajTransakcji;

    private pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaOSPozMT[] komunikatTransakcjaOSPoz;

    public KomunikatTransakcjaOSMT() {
    }

    public KomunikatTransakcjaOSMT(
           java.util.Calendar dataCzasTransakcji,
           java.math.BigInteger lp,
           java.lang.String adresPodmDrugaStrona,
           int czyTransakcjaJestKorekta,
           java.util.Calendar dataDokKorygowanego,
           java.lang.String idBiznesowyPodmDrugaStrona,
           pl.gov.csioz.zsmopl.mt.IdentyfikatorMPDPodmiotuDrugaStronaMT idMPDPodmDrugaStrona,
           java.lang.String krajPodmDrugaStrona,
           java.lang.String nazwaPodmDrugaStrona,
           java.lang.String nrDokKorygowanego,
           java.lang.String[] nrDokSprzZakRefDokMag,
           java.lang.String nrDokZewnetrznego,
           java.lang.String nrDokZrodl,
           java.lang.String nrERecepty,
           pl.gov.csioz.zsmopl.mt.PodstawaWydaniaLekuMT podstawaWydaniaLeku,
           java.lang.String przyczynaRoznicyInwentaryzacyjnej,
           pl.gov.csioz.zsmopl.mt.RodzajDokZrodlSprzMT rodzajDokZrodlSprz,
           java.lang.String rodzajPodmDrugaStrona,
           pl.gov.csioz.zsmopl.mt.RodzajTransObrotuIStanuMT rodzajTransakcji,
           pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaOSPozMT[] komunikatTransakcjaOSPoz) {
        super(
            dataCzasTransakcji,
            lp);
        this.adresPodmDrugaStrona = adresPodmDrugaStrona;
        this.czyTransakcjaJestKorekta = czyTransakcjaJestKorekta;
        this.dataDokKorygowanego = dataDokKorygowanego;
        this.idBiznesowyPodmDrugaStrona = idBiznesowyPodmDrugaStrona;
        this.idMPDPodmDrugaStrona = idMPDPodmDrugaStrona;
        this.krajPodmDrugaStrona = krajPodmDrugaStrona;
        this.nazwaPodmDrugaStrona = nazwaPodmDrugaStrona;
        this.nrDokKorygowanego = nrDokKorygowanego;
        this.nrDokSprzZakRefDokMag = nrDokSprzZakRefDokMag;
        this.nrDokZewnetrznego = nrDokZewnetrznego;
        this.nrDokZrodl = nrDokZrodl;
        this.nrERecepty = nrERecepty;
        this.podstawaWydaniaLeku = podstawaWydaniaLeku;
        this.przyczynaRoznicyInwentaryzacyjnej = przyczynaRoznicyInwentaryzacyjnej;
        this.rodzajDokZrodlSprz = rodzajDokZrodlSprz;
        this.rodzajPodmDrugaStrona = rodzajPodmDrugaStrona;
        this.rodzajTransakcji = rodzajTransakcji;
        this.komunikatTransakcjaOSPoz = komunikatTransakcjaOSPoz;
    }


    /**
     * Gets the adresPodmDrugaStrona value for this KomunikatTransakcjaOSMT.
     * 
     * @return adresPodmDrugaStrona
     */
    public java.lang.String getAdresPodmDrugaStrona() {
        return adresPodmDrugaStrona;
    }


    /**
     * Sets the adresPodmDrugaStrona value for this KomunikatTransakcjaOSMT.
     * 
     * @param adresPodmDrugaStrona
     */
    public void setAdresPodmDrugaStrona(java.lang.String adresPodmDrugaStrona) {
        this.adresPodmDrugaStrona = adresPodmDrugaStrona;
    }


    /**
     * Gets the czyTransakcjaJestKorekta value for this KomunikatTransakcjaOSMT.
     * 
     * @return czyTransakcjaJestKorekta
     */
    public int getCzyTransakcjaJestKorekta() {
        return czyTransakcjaJestKorekta;
    }


    /**
     * Sets the czyTransakcjaJestKorekta value for this KomunikatTransakcjaOSMT.
     * 
     * @param czyTransakcjaJestKorekta
     */
    public void setCzyTransakcjaJestKorekta(int czyTransakcjaJestKorekta) {
        this.czyTransakcjaJestKorekta = czyTransakcjaJestKorekta;
    }


    /**
     * Gets the dataDokKorygowanego value for this KomunikatTransakcjaOSMT.
     * 
     * @return dataDokKorygowanego
     */
    public java.util.Calendar getDataDokKorygowanego() {
        return dataDokKorygowanego;
    }


    /**
     * Sets the dataDokKorygowanego value for this KomunikatTransakcjaOSMT.
     * 
     * @param dataDokKorygowanego
     */
    public void setDataDokKorygowanego(java.util.Calendar dataDokKorygowanego) {
        this.dataDokKorygowanego = dataDokKorygowanego;
    }


    /**
     * Gets the idBiznesowyPodmDrugaStrona value for this KomunikatTransakcjaOSMT.
     * 
     * @return idBiznesowyPodmDrugaStrona
     */
    public java.lang.String getIdBiznesowyPodmDrugaStrona() {
        return idBiznesowyPodmDrugaStrona;
    }


    /**
     * Sets the idBiznesowyPodmDrugaStrona value for this KomunikatTransakcjaOSMT.
     * 
     * @param idBiznesowyPodmDrugaStrona
     */
    public void setIdBiznesowyPodmDrugaStrona(java.lang.String idBiznesowyPodmDrugaStrona) {
        this.idBiznesowyPodmDrugaStrona = idBiznesowyPodmDrugaStrona;
    }


    /**
     * Gets the idMPDPodmDrugaStrona value for this KomunikatTransakcjaOSMT.
     * 
     * @return idMPDPodmDrugaStrona
     */
    public pl.gov.csioz.zsmopl.mt.IdentyfikatorMPDPodmiotuDrugaStronaMT getIdMPDPodmDrugaStrona() {
        return idMPDPodmDrugaStrona;
    }


    /**
     * Sets the idMPDPodmDrugaStrona value for this KomunikatTransakcjaOSMT.
     * 
     * @param idMPDPodmDrugaStrona
     */
    public void setIdMPDPodmDrugaStrona(pl.gov.csioz.zsmopl.mt.IdentyfikatorMPDPodmiotuDrugaStronaMT idMPDPodmDrugaStrona) {
        this.idMPDPodmDrugaStrona = idMPDPodmDrugaStrona;
    }


    /**
     * Gets the krajPodmDrugaStrona value for this KomunikatTransakcjaOSMT.
     * 
     * @return krajPodmDrugaStrona
     */
    public java.lang.String getKrajPodmDrugaStrona() {
        return krajPodmDrugaStrona;
    }


    /**
     * Sets the krajPodmDrugaStrona value for this KomunikatTransakcjaOSMT.
     * 
     * @param krajPodmDrugaStrona
     */
    public void setKrajPodmDrugaStrona(java.lang.String krajPodmDrugaStrona) {
        this.krajPodmDrugaStrona = krajPodmDrugaStrona;
    }


    /**
     * Gets the nazwaPodmDrugaStrona value for this KomunikatTransakcjaOSMT.
     * 
     * @return nazwaPodmDrugaStrona
     */
    public java.lang.String getNazwaPodmDrugaStrona() {
        return nazwaPodmDrugaStrona;
    }


    /**
     * Sets the nazwaPodmDrugaStrona value for this KomunikatTransakcjaOSMT.
     * 
     * @param nazwaPodmDrugaStrona
     */
    public void setNazwaPodmDrugaStrona(java.lang.String nazwaPodmDrugaStrona) {
        this.nazwaPodmDrugaStrona = nazwaPodmDrugaStrona;
    }


    /**
     * Gets the nrDokKorygowanego value for this KomunikatTransakcjaOSMT.
     * 
     * @return nrDokKorygowanego
     */
    public java.lang.String getNrDokKorygowanego() {
        return nrDokKorygowanego;
    }


    /**
     * Sets the nrDokKorygowanego value for this KomunikatTransakcjaOSMT.
     * 
     * @param nrDokKorygowanego
     */
    public void setNrDokKorygowanego(java.lang.String nrDokKorygowanego) {
        this.nrDokKorygowanego = nrDokKorygowanego;
    }


    /**
     * Gets the nrDokSprzZakRefDokMag value for this KomunikatTransakcjaOSMT.
     * 
     * @return nrDokSprzZakRefDokMag
     */
    public java.lang.String[] getNrDokSprzZakRefDokMag() {
        return nrDokSprzZakRefDokMag;
    }


    /**
     * Sets the nrDokSprzZakRefDokMag value for this KomunikatTransakcjaOSMT.
     * 
     * @param nrDokSprzZakRefDokMag
     */
    public void setNrDokSprzZakRefDokMag(java.lang.String[] nrDokSprzZakRefDokMag) {
        this.nrDokSprzZakRefDokMag = nrDokSprzZakRefDokMag;
    }

    public java.lang.String getNrDokSprzZakRefDokMag(int i) {
        return this.nrDokSprzZakRefDokMag[i];
    }

    public void setNrDokSprzZakRefDokMag(int i, java.lang.String _value) {
        this.nrDokSprzZakRefDokMag[i] = _value;
    }


    /**
     * Gets the nrDokZewnetrznego value for this KomunikatTransakcjaOSMT.
     * 
     * @return nrDokZewnetrznego
     */
    public java.lang.String getNrDokZewnetrznego() {
        return nrDokZewnetrznego;
    }


    /**
     * Sets the nrDokZewnetrznego value for this KomunikatTransakcjaOSMT.
     * 
     * @param nrDokZewnetrznego
     */
    public void setNrDokZewnetrznego(java.lang.String nrDokZewnetrznego) {
        this.nrDokZewnetrznego = nrDokZewnetrznego;
    }


    /**
     * Gets the nrDokZrodl value for this KomunikatTransakcjaOSMT.
     * 
     * @return nrDokZrodl
     */
    public java.lang.String getNrDokZrodl() {
        return nrDokZrodl;
    }


    /**
     * Sets the nrDokZrodl value for this KomunikatTransakcjaOSMT.
     * 
     * @param nrDokZrodl
     */
    public void setNrDokZrodl(java.lang.String nrDokZrodl) {
        this.nrDokZrodl = nrDokZrodl;
    }


    /**
     * Gets the nrERecepty value for this KomunikatTransakcjaOSMT.
     * 
     * @return nrERecepty
     */
    public java.lang.String getNrERecepty() {
        return nrERecepty;
    }


    /**
     * Sets the nrERecepty value for this KomunikatTransakcjaOSMT.
     * 
     * @param nrERecepty
     */
    public void setNrERecepty(java.lang.String nrERecepty) {
        this.nrERecepty = nrERecepty;
    }


    /**
     * Gets the podstawaWydaniaLeku value for this KomunikatTransakcjaOSMT.
     * 
     * @return podstawaWydaniaLeku
     */
    public pl.gov.csioz.zsmopl.mt.PodstawaWydaniaLekuMT getPodstawaWydaniaLeku() {
        return podstawaWydaniaLeku;
    }


    /**
     * Sets the podstawaWydaniaLeku value for this KomunikatTransakcjaOSMT.
     * 
     * @param podstawaWydaniaLeku
     */
    public void setPodstawaWydaniaLeku(pl.gov.csioz.zsmopl.mt.PodstawaWydaniaLekuMT podstawaWydaniaLeku) {
        this.podstawaWydaniaLeku = podstawaWydaniaLeku;
    }


    /**
     * Gets the przyczynaRoznicyInwentaryzacyjnej value for this KomunikatTransakcjaOSMT.
     * 
     * @return przyczynaRoznicyInwentaryzacyjnej
     */
    public java.lang.String getPrzyczynaRoznicyInwentaryzacyjnej() {
        return przyczynaRoznicyInwentaryzacyjnej;
    }


    /**
     * Sets the przyczynaRoznicyInwentaryzacyjnej value for this KomunikatTransakcjaOSMT.
     * 
     * @param przyczynaRoznicyInwentaryzacyjnej
     */
    public void setPrzyczynaRoznicyInwentaryzacyjnej(java.lang.String przyczynaRoznicyInwentaryzacyjnej) {
        this.przyczynaRoznicyInwentaryzacyjnej = przyczynaRoznicyInwentaryzacyjnej;
    }


    /**
     * Gets the rodzajDokZrodlSprz value for this KomunikatTransakcjaOSMT.
     * 
     * @return rodzajDokZrodlSprz
     */
    public pl.gov.csioz.zsmopl.mt.RodzajDokZrodlSprzMT getRodzajDokZrodlSprz() {
        return rodzajDokZrodlSprz;
    }


    /**
     * Sets the rodzajDokZrodlSprz value for this KomunikatTransakcjaOSMT.
     * 
     * @param rodzajDokZrodlSprz
     */
    public void setRodzajDokZrodlSprz(pl.gov.csioz.zsmopl.mt.RodzajDokZrodlSprzMT rodzajDokZrodlSprz) {
        this.rodzajDokZrodlSprz = rodzajDokZrodlSprz;
    }


    /**
     * Gets the rodzajPodmDrugaStrona value for this KomunikatTransakcjaOSMT.
     * 
     * @return rodzajPodmDrugaStrona
     */
    public java.lang.String getRodzajPodmDrugaStrona() {
        return rodzajPodmDrugaStrona;
    }


    /**
     * Sets the rodzajPodmDrugaStrona value for this KomunikatTransakcjaOSMT.
     * 
     * @param rodzajPodmDrugaStrona
     */
    public void setRodzajPodmDrugaStrona(java.lang.String rodzajPodmDrugaStrona) {
        this.rodzajPodmDrugaStrona = rodzajPodmDrugaStrona;
    }


    /**
     * Gets the rodzajTransakcji value for this KomunikatTransakcjaOSMT.
     * 
     * @return rodzajTransakcji
     */
    public pl.gov.csioz.zsmopl.mt.RodzajTransObrotuIStanuMT getRodzajTransakcji() {
        return rodzajTransakcji;
    }


    /**
     * Sets the rodzajTransakcji value for this KomunikatTransakcjaOSMT.
     * 
     * @param rodzajTransakcji
     */
    public void setRodzajTransakcji(pl.gov.csioz.zsmopl.mt.RodzajTransObrotuIStanuMT rodzajTransakcji) {
        this.rodzajTransakcji = rodzajTransakcji;
    }


    /**
     * Gets the komunikatTransakcjaOSPoz value for this KomunikatTransakcjaOSMT.
     * 
     * @return komunikatTransakcjaOSPoz
     */
    public pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaOSPozMT[] getKomunikatTransakcjaOSPoz() {
        return komunikatTransakcjaOSPoz;
    }


    /**
     * Sets the komunikatTransakcjaOSPoz value for this KomunikatTransakcjaOSMT.
     * 
     * @param komunikatTransakcjaOSPoz
     */
    public void setKomunikatTransakcjaOSPoz(pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaOSPozMT[] komunikatTransakcjaOSPoz) {
        this.komunikatTransakcjaOSPoz = komunikatTransakcjaOSPoz;
    }

    public pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaOSPozMT getKomunikatTransakcjaOSPoz(int i) {
        return this.komunikatTransakcjaOSPoz[i];
    }

    public void setKomunikatTransakcjaOSPoz(int i, pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaOSPozMT _value) {
        this.komunikatTransakcjaOSPoz[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof KomunikatTransakcjaOSMT)) return false;
        KomunikatTransakcjaOSMT other = (KomunikatTransakcjaOSMT) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.adresPodmDrugaStrona==null && other.getAdresPodmDrugaStrona()==null) || 
             (this.adresPodmDrugaStrona!=null &&
              this.adresPodmDrugaStrona.equals(other.getAdresPodmDrugaStrona()))) &&
            this.czyTransakcjaJestKorekta == other.getCzyTransakcjaJestKorekta() &&
            ((this.dataDokKorygowanego==null && other.getDataDokKorygowanego()==null) || 
             (this.dataDokKorygowanego!=null &&
              this.dataDokKorygowanego.equals(other.getDataDokKorygowanego()))) &&
            ((this.idBiznesowyPodmDrugaStrona==null && other.getIdBiznesowyPodmDrugaStrona()==null) || 
             (this.idBiznesowyPodmDrugaStrona!=null &&
              this.idBiznesowyPodmDrugaStrona.equals(other.getIdBiznesowyPodmDrugaStrona()))) &&
            ((this.idMPDPodmDrugaStrona==null && other.getIdMPDPodmDrugaStrona()==null) || 
             (this.idMPDPodmDrugaStrona!=null &&
              this.idMPDPodmDrugaStrona.equals(other.getIdMPDPodmDrugaStrona()))) &&
            ((this.krajPodmDrugaStrona==null && other.getKrajPodmDrugaStrona()==null) || 
             (this.krajPodmDrugaStrona!=null &&
              this.krajPodmDrugaStrona.equals(other.getKrajPodmDrugaStrona()))) &&
            ((this.nazwaPodmDrugaStrona==null && other.getNazwaPodmDrugaStrona()==null) || 
             (this.nazwaPodmDrugaStrona!=null &&
              this.nazwaPodmDrugaStrona.equals(other.getNazwaPodmDrugaStrona()))) &&
            ((this.nrDokKorygowanego==null && other.getNrDokKorygowanego()==null) || 
             (this.nrDokKorygowanego!=null &&
              this.nrDokKorygowanego.equals(other.getNrDokKorygowanego()))) &&
            ((this.nrDokSprzZakRefDokMag==null && other.getNrDokSprzZakRefDokMag()==null) || 
             (this.nrDokSprzZakRefDokMag!=null &&
              java.util.Arrays.equals(this.nrDokSprzZakRefDokMag, other.getNrDokSprzZakRefDokMag()))) &&
            ((this.nrDokZewnetrznego==null && other.getNrDokZewnetrznego()==null) || 
             (this.nrDokZewnetrznego!=null &&
              this.nrDokZewnetrznego.equals(other.getNrDokZewnetrznego()))) &&
            ((this.nrDokZrodl==null && other.getNrDokZrodl()==null) || 
             (this.nrDokZrodl!=null &&
              this.nrDokZrodl.equals(other.getNrDokZrodl()))) &&
            ((this.nrERecepty==null && other.getNrERecepty()==null) || 
             (this.nrERecepty!=null &&
              this.nrERecepty.equals(other.getNrERecepty()))) &&
            ((this.podstawaWydaniaLeku==null && other.getPodstawaWydaniaLeku()==null) || 
             (this.podstawaWydaniaLeku!=null &&
              this.podstawaWydaniaLeku.equals(other.getPodstawaWydaniaLeku()))) &&
            ((this.przyczynaRoznicyInwentaryzacyjnej==null && other.getPrzyczynaRoznicyInwentaryzacyjnej()==null) || 
             (this.przyczynaRoznicyInwentaryzacyjnej!=null &&
              this.przyczynaRoznicyInwentaryzacyjnej.equals(other.getPrzyczynaRoznicyInwentaryzacyjnej()))) &&
            ((this.rodzajDokZrodlSprz==null && other.getRodzajDokZrodlSprz()==null) || 
             (this.rodzajDokZrodlSprz!=null &&
              this.rodzajDokZrodlSprz.equals(other.getRodzajDokZrodlSprz()))) &&
            ((this.rodzajPodmDrugaStrona==null && other.getRodzajPodmDrugaStrona()==null) || 
             (this.rodzajPodmDrugaStrona!=null &&
              this.rodzajPodmDrugaStrona.equals(other.getRodzajPodmDrugaStrona()))) &&
            ((this.rodzajTransakcji==null && other.getRodzajTransakcji()==null) || 
             (this.rodzajTransakcji!=null &&
              this.rodzajTransakcji.equals(other.getRodzajTransakcji()))) &&
            ((this.komunikatTransakcjaOSPoz==null && other.getKomunikatTransakcjaOSPoz()==null) || 
             (this.komunikatTransakcjaOSPoz!=null &&
              java.util.Arrays.equals(this.komunikatTransakcjaOSPoz, other.getKomunikatTransakcjaOSPoz())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAdresPodmDrugaStrona() != null) {
            _hashCode += getAdresPodmDrugaStrona().hashCode();
        }
        _hashCode += getCzyTransakcjaJestKorekta();
        if (getDataDokKorygowanego() != null) {
            _hashCode += getDataDokKorygowanego().hashCode();
        }
        if (getIdBiznesowyPodmDrugaStrona() != null) {
            _hashCode += getIdBiznesowyPodmDrugaStrona().hashCode();
        }
        if (getIdMPDPodmDrugaStrona() != null) {
            _hashCode += getIdMPDPodmDrugaStrona().hashCode();
        }
        if (getKrajPodmDrugaStrona() != null) {
            _hashCode += getKrajPodmDrugaStrona().hashCode();
        }
        if (getNazwaPodmDrugaStrona() != null) {
            _hashCode += getNazwaPodmDrugaStrona().hashCode();
        }
        if (getNrDokKorygowanego() != null) {
            _hashCode += getNrDokKorygowanego().hashCode();
        }
        if (getNrDokSprzZakRefDokMag() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getNrDokSprzZakRefDokMag());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getNrDokSprzZakRefDokMag(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getNrDokZewnetrznego() != null) {
            _hashCode += getNrDokZewnetrznego().hashCode();
        }
        if (getNrDokZrodl() != null) {
            _hashCode += getNrDokZrodl().hashCode();
        }
        if (getNrERecepty() != null) {
            _hashCode += getNrERecepty().hashCode();
        }
        if (getPodstawaWydaniaLeku() != null) {
            _hashCode += getPodstawaWydaniaLeku().hashCode();
        }
        if (getPrzyczynaRoznicyInwentaryzacyjnej() != null) {
            _hashCode += getPrzyczynaRoznicyInwentaryzacyjnej().hashCode();
        }
        if (getRodzajDokZrodlSprz() != null) {
            _hashCode += getRodzajDokZrodlSprz().hashCode();
        }
        if (getRodzajPodmDrugaStrona() != null) {
            _hashCode += getRodzajPodmDrugaStrona().hashCode();
        }
        if (getRodzajTransakcji() != null) {
            _hashCode += getRodzajTransakcji().hashCode();
        }
        if (getKomunikatTransakcjaOSPoz() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getKomunikatTransakcjaOSPoz());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getKomunikatTransakcjaOSPoz(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(KomunikatTransakcjaOSMT.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "KomunikatTransakcjaOSMT"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adresPodmDrugaStrona");
        elemField.setXmlName(new javax.xml.namespace.QName("", "adresPodmDrugaStrona"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("czyTransakcjaJestKorekta");
        elemField.setXmlName(new javax.xml.namespace.QName("", "czyTransakcjaJestKorekta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataDokKorygowanego");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dataDokKorygowanego"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idBiznesowyPodmDrugaStrona");
        elemField.setXmlName(new javax.xml.namespace.QName("", "idBiznesowyPodmDrugaStrona"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idMPDPodmDrugaStrona");
        elemField.setXmlName(new javax.xml.namespace.QName("", "idMPDPodmDrugaStrona"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "IdentyfikatorMPDPodmiotuDrugaStronaMT"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("krajPodmDrugaStrona");
        elemField.setXmlName(new javax.xml.namespace.QName("", "krajPodmDrugaStrona"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nazwaPodmDrugaStrona");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nazwaPodmDrugaStrona"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nrDokKorygowanego");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nrDokKorygowanego"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nrDokSprzZakRefDokMag");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nrDokSprzZakRefDokMag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nrDokZewnetrznego");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nrDokZewnetrznego"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nrDokZrodl");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nrDokZrodl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nrERecepty");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nrERecepty"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("podstawaWydaniaLeku");
        elemField.setXmlName(new javax.xml.namespace.QName("", "podstawaWydaniaLeku"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "PodstawaWydaniaLekuMT"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("przyczynaRoznicyInwentaryzacyjnej");
        elemField.setXmlName(new javax.xml.namespace.QName("", "przyczynaRoznicyInwentaryzacyjnej"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rodzajDokZrodlSprz");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rodzajDokZrodlSprz"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "RodzajDokZrodlSprzMT"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rodzajPodmDrugaStrona");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rodzajPodmDrugaStrona"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rodzajTransakcji");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rodzajTransakcji"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "RodzajTransObrotuIStanuMT"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("komunikatTransakcjaOSPoz");
        elemField.setXmlName(new javax.xml.namespace.QName("", "komunikatTransakcjaOSPoz"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "KomunikatTransakcjaOSPozMT"));
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
