/**
 * KomunikatTransakcjaOSPozStanMT.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package pl.gov.csioz.zsmopl.mt;


/**
 * Informacje o stanach  - obiekt powinien istnieć, jeśli transakcja
 * należy do jednego z rejestrów:
 *                 (P) Rejestr przyjęć magazynowych
 *                 (W) Rejestr wydań magazynowych
 *                 (I) Rejestr pozostałych transakcji.
 */
public class KomunikatTransakcjaOSPozStanMT  implements java.io.Serializable {
    private java.math.BigDecimal stanIloscDostepny;

    private java.math.BigDecimal stanIloscDostepnySeria;

    private java.math.BigDecimal stanIloscWstrzWycof;

    private java.math.BigDecimal stanIloscWstrzWycofSeria;

    private java.math.BigDecimal stanWartoscDostepny;

    private java.math.BigDecimal stanWartoscDostepnySeria;

    private java.math.BigDecimal stanWartoscWstrzWycof;

    private java.math.BigDecimal stanWartoscWstrzWycofSeria;

    public KomunikatTransakcjaOSPozStanMT() {
    }

    public KomunikatTransakcjaOSPozStanMT(
           java.math.BigDecimal stanIloscDostepny,
           java.math.BigDecimal stanIloscDostepnySeria,
           java.math.BigDecimal stanIloscWstrzWycof,
           java.math.BigDecimal stanIloscWstrzWycofSeria,
           java.math.BigDecimal stanWartoscDostepny,
           java.math.BigDecimal stanWartoscDostepnySeria,
           java.math.BigDecimal stanWartoscWstrzWycof,
           java.math.BigDecimal stanWartoscWstrzWycofSeria) {
           this.stanIloscDostepny = stanIloscDostepny;
           this.stanIloscDostepnySeria = stanIloscDostepnySeria;
           this.stanIloscWstrzWycof = stanIloscWstrzWycof;
           this.stanIloscWstrzWycofSeria = stanIloscWstrzWycofSeria;
           this.stanWartoscDostepny = stanWartoscDostepny;
           this.stanWartoscDostepnySeria = stanWartoscDostepnySeria;
           this.stanWartoscWstrzWycof = stanWartoscWstrzWycof;
           this.stanWartoscWstrzWycofSeria = stanWartoscWstrzWycofSeria;
    }


    /**
     * Gets the stanIloscDostepny value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @return stanIloscDostepny
     */
    public java.math.BigDecimal getStanIloscDostepny() {
        return stanIloscDostepny;
    }


    /**
     * Sets the stanIloscDostepny value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @param stanIloscDostepny
     */
    public void setStanIloscDostepny(java.math.BigDecimal stanIloscDostepny) {
        this.stanIloscDostepny = stanIloscDostepny;
    }


    /**
     * Gets the stanIloscDostepnySeria value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @return stanIloscDostepnySeria
     */
    public java.math.BigDecimal getStanIloscDostepnySeria() {
        return stanIloscDostepnySeria;
    }


    /**
     * Sets the stanIloscDostepnySeria value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @param stanIloscDostepnySeria
     */
    public void setStanIloscDostepnySeria(java.math.BigDecimal stanIloscDostepnySeria) {
        this.stanIloscDostepnySeria = stanIloscDostepnySeria;
    }


    /**
     * Gets the stanIloscWstrzWycof value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @return stanIloscWstrzWycof
     */
    public java.math.BigDecimal getStanIloscWstrzWycof() {
        return stanIloscWstrzWycof;
    }


    /**
     * Sets the stanIloscWstrzWycof value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @param stanIloscWstrzWycof
     */
    public void setStanIloscWstrzWycof(java.math.BigDecimal stanIloscWstrzWycof) {
        this.stanIloscWstrzWycof = stanIloscWstrzWycof;
    }


    /**
     * Gets the stanIloscWstrzWycofSeria value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @return stanIloscWstrzWycofSeria
     */
    public java.math.BigDecimal getStanIloscWstrzWycofSeria() {
        return stanIloscWstrzWycofSeria;
    }


    /**
     * Sets the stanIloscWstrzWycofSeria value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @param stanIloscWstrzWycofSeria
     */
    public void setStanIloscWstrzWycofSeria(java.math.BigDecimal stanIloscWstrzWycofSeria) {
        this.stanIloscWstrzWycofSeria = stanIloscWstrzWycofSeria;
    }


    /**
     * Gets the stanWartoscDostepny value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @return stanWartoscDostepny
     */
    public java.math.BigDecimal getStanWartoscDostepny() {
        return stanWartoscDostepny;
    }


    /**
     * Sets the stanWartoscDostepny value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @param stanWartoscDostepny
     */
    public void setStanWartoscDostepny(java.math.BigDecimal stanWartoscDostepny) {
        this.stanWartoscDostepny = stanWartoscDostepny;
    }


    /**
     * Gets the stanWartoscDostepnySeria value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @return stanWartoscDostepnySeria
     */
    public java.math.BigDecimal getStanWartoscDostepnySeria() {
        return stanWartoscDostepnySeria;
    }


    /**
     * Sets the stanWartoscDostepnySeria value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @param stanWartoscDostepnySeria
     */
    public void setStanWartoscDostepnySeria(java.math.BigDecimal stanWartoscDostepnySeria) {
        this.stanWartoscDostepnySeria = stanWartoscDostepnySeria;
    }


    /**
     * Gets the stanWartoscWstrzWycof value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @return stanWartoscWstrzWycof
     */
    public java.math.BigDecimal getStanWartoscWstrzWycof() {
        return stanWartoscWstrzWycof;
    }


    /**
     * Sets the stanWartoscWstrzWycof value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @param stanWartoscWstrzWycof
     */
    public void setStanWartoscWstrzWycof(java.math.BigDecimal stanWartoscWstrzWycof) {
        this.stanWartoscWstrzWycof = stanWartoscWstrzWycof;
    }


    /**
     * Gets the stanWartoscWstrzWycofSeria value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @return stanWartoscWstrzWycofSeria
     */
    public java.math.BigDecimal getStanWartoscWstrzWycofSeria() {
        return stanWartoscWstrzWycofSeria;
    }


    /**
     * Sets the stanWartoscWstrzWycofSeria value for this KomunikatTransakcjaOSPozStanMT.
     * 
     * @param stanWartoscWstrzWycofSeria
     */
    public void setStanWartoscWstrzWycofSeria(java.math.BigDecimal stanWartoscWstrzWycofSeria) {
        this.stanWartoscWstrzWycofSeria = stanWartoscWstrzWycofSeria;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof KomunikatTransakcjaOSPozStanMT)) return false;
        KomunikatTransakcjaOSPozStanMT other = (KomunikatTransakcjaOSPozStanMT) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.stanIloscDostepny==null && other.getStanIloscDostepny()==null) || 
             (this.stanIloscDostepny!=null &&
              this.stanIloscDostepny.equals(other.getStanIloscDostepny()))) &&
            ((this.stanIloscDostepnySeria==null && other.getStanIloscDostepnySeria()==null) || 
             (this.stanIloscDostepnySeria!=null &&
              this.stanIloscDostepnySeria.equals(other.getStanIloscDostepnySeria()))) &&
            ((this.stanIloscWstrzWycof==null && other.getStanIloscWstrzWycof()==null) || 
             (this.stanIloscWstrzWycof!=null &&
              this.stanIloscWstrzWycof.equals(other.getStanIloscWstrzWycof()))) &&
            ((this.stanIloscWstrzWycofSeria==null && other.getStanIloscWstrzWycofSeria()==null) || 
             (this.stanIloscWstrzWycofSeria!=null &&
              this.stanIloscWstrzWycofSeria.equals(other.getStanIloscWstrzWycofSeria()))) &&
            ((this.stanWartoscDostepny==null && other.getStanWartoscDostepny()==null) || 
             (this.stanWartoscDostepny!=null &&
              this.stanWartoscDostepny.equals(other.getStanWartoscDostepny()))) &&
            ((this.stanWartoscDostepnySeria==null && other.getStanWartoscDostepnySeria()==null) || 
             (this.stanWartoscDostepnySeria!=null &&
              this.stanWartoscDostepnySeria.equals(other.getStanWartoscDostepnySeria()))) &&
            ((this.stanWartoscWstrzWycof==null && other.getStanWartoscWstrzWycof()==null) || 
             (this.stanWartoscWstrzWycof!=null &&
              this.stanWartoscWstrzWycof.equals(other.getStanWartoscWstrzWycof()))) &&
            ((this.stanWartoscWstrzWycofSeria==null && other.getStanWartoscWstrzWycofSeria()==null) || 
             (this.stanWartoscWstrzWycofSeria!=null &&
              this.stanWartoscWstrzWycofSeria.equals(other.getStanWartoscWstrzWycofSeria())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getStanIloscDostepny() != null) {
            _hashCode += getStanIloscDostepny().hashCode();
        }
        if (getStanIloscDostepnySeria() != null) {
            _hashCode += getStanIloscDostepnySeria().hashCode();
        }
        if (getStanIloscWstrzWycof() != null) {
            _hashCode += getStanIloscWstrzWycof().hashCode();
        }
        if (getStanIloscWstrzWycofSeria() != null) {
            _hashCode += getStanIloscWstrzWycofSeria().hashCode();
        }
        if (getStanWartoscDostepny() != null) {
            _hashCode += getStanWartoscDostepny().hashCode();
        }
        if (getStanWartoscDostepnySeria() != null) {
            _hashCode += getStanWartoscDostepnySeria().hashCode();
        }
        if (getStanWartoscWstrzWycof() != null) {
            _hashCode += getStanWartoscWstrzWycof().hashCode();
        }
        if (getStanWartoscWstrzWycofSeria() != null) {
            _hashCode += getStanWartoscWstrzWycofSeria().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(KomunikatTransakcjaOSPozStanMT.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "KomunikatTransakcjaOSPozStanMT"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stanIloscDostepny");
        elemField.setXmlName(new javax.xml.namespace.QName("", "stanIloscDostepny"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stanIloscDostepnySeria");
        elemField.setXmlName(new javax.xml.namespace.QName("", "stanIloscDostepnySeria"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stanIloscWstrzWycof");
        elemField.setXmlName(new javax.xml.namespace.QName("", "stanIloscWstrzWycof"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stanIloscWstrzWycofSeria");
        elemField.setXmlName(new javax.xml.namespace.QName("", "stanIloscWstrzWycofSeria"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stanWartoscDostepny");
        elemField.setXmlName(new javax.xml.namespace.QName("", "stanWartoscDostepny"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stanWartoscDostepnySeria");
        elemField.setXmlName(new javax.xml.namespace.QName("", "stanWartoscDostepnySeria"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stanWartoscWstrzWycof");
        elemField.setXmlName(new javax.xml.namespace.QName("", "stanWartoscWstrzWycof"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stanWartoscWstrzWycofSeria");
        elemField.setXmlName(new javax.xml.namespace.QName("", "stanWartoscWstrzWycofSeria"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
