/**
 * KomunikatTransakcjaOSPozZapMT.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package pl.gov.csioz.zsmopl.mt;


/**
 * Charakterystyka produktu leczniczego z importu docelowego i interwencyjnego
 * - obiekt
 *                 powinien istnieć, jeśli pozycja transakcji dotyczy
 * importu docelowego lub interwencyjnego, tzn. gdy
 *                 komunikatTransakcjaOSPozMT.czyDotImportuDocelInterw==1.
 * Na charakterystykę produktu leczniczego składają się pola:
 *                 - kod handlowy (EAN lub równoważny),
 *                 - nazwa handlowa,
 *                 - nazwa międzynarodowa, 
 *                 - postać farmaceutyczna, 
 *                 - dawka, 
 *                 - wielkość opakowania,
 *                 - nazwa producenta, 
 *                 - kraj pochodzenia.
 */
public class KomunikatTransakcjaOSPozZapMT  implements java.io.Serializable {
    private java.lang.String dawka;

    private java.lang.String kodEAN;

    private java.lang.String krajPochodzenia;

    private java.lang.String nazwaHandlowa;

    private java.lang.String nazwaMiedzynarodowa;

    private java.lang.String postac;

    private java.lang.String producent;

    private java.lang.String wielkoscOpakowania;

    public KomunikatTransakcjaOSPozZapMT() {
    }

    public KomunikatTransakcjaOSPozZapMT(
           java.lang.String dawka,
           java.lang.String kodEAN,
           java.lang.String krajPochodzenia,
           java.lang.String nazwaHandlowa,
           java.lang.String nazwaMiedzynarodowa,
           java.lang.String postac,
           java.lang.String producent,
           java.lang.String wielkoscOpakowania) {
           this.dawka = dawka;
           this.kodEAN = kodEAN;
           this.krajPochodzenia = krajPochodzenia;
           this.nazwaHandlowa = nazwaHandlowa;
           this.nazwaMiedzynarodowa = nazwaMiedzynarodowa;
           this.postac = postac;
           this.producent = producent;
           this.wielkoscOpakowania = wielkoscOpakowania;
    }


    /**
     * Gets the dawka value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @return dawka
     */
    public java.lang.String getDawka() {
        return dawka;
    }


    /**
     * Sets the dawka value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @param dawka
     */
    public void setDawka(java.lang.String dawka) {
        this.dawka = dawka;
    }


    /**
     * Gets the kodEAN value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @return kodEAN
     */
    public java.lang.String getKodEAN() {
        return kodEAN;
    }


    /**
     * Sets the kodEAN value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @param kodEAN
     */
    public void setKodEAN(java.lang.String kodEAN) {
        this.kodEAN = kodEAN;
    }


    /**
     * Gets the krajPochodzenia value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @return krajPochodzenia
     */
    public java.lang.String getKrajPochodzenia() {
        return krajPochodzenia;
    }


    /**
     * Sets the krajPochodzenia value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @param krajPochodzenia
     */
    public void setKrajPochodzenia(java.lang.String krajPochodzenia) {
        this.krajPochodzenia = krajPochodzenia;
    }


    /**
     * Gets the nazwaHandlowa value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @return nazwaHandlowa
     */
    public java.lang.String getNazwaHandlowa() {
        return nazwaHandlowa;
    }


    /**
     * Sets the nazwaHandlowa value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @param nazwaHandlowa
     */
    public void setNazwaHandlowa(java.lang.String nazwaHandlowa) {
        this.nazwaHandlowa = nazwaHandlowa;
    }


    /**
     * Gets the nazwaMiedzynarodowa value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @return nazwaMiedzynarodowa
     */
    public java.lang.String getNazwaMiedzynarodowa() {
        return nazwaMiedzynarodowa;
    }


    /**
     * Sets the nazwaMiedzynarodowa value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @param nazwaMiedzynarodowa
     */
    public void setNazwaMiedzynarodowa(java.lang.String nazwaMiedzynarodowa) {
        this.nazwaMiedzynarodowa = nazwaMiedzynarodowa;
    }


    /**
     * Gets the postac value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @return postac
     */
    public java.lang.String getPostac() {
        return postac;
    }


    /**
     * Sets the postac value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @param postac
     */
    public void setPostac(java.lang.String postac) {
        this.postac = postac;
    }


    /**
     * Gets the producent value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @return producent
     */
    public java.lang.String getProducent() {
        return producent;
    }


    /**
     * Sets the producent value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @param producent
     */
    public void setProducent(java.lang.String producent) {
        this.producent = producent;
    }


    /**
     * Gets the wielkoscOpakowania value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @return wielkoscOpakowania
     */
    public java.lang.String getWielkoscOpakowania() {
        return wielkoscOpakowania;
    }


    /**
     * Sets the wielkoscOpakowania value for this KomunikatTransakcjaOSPozZapMT.
     * 
     * @param wielkoscOpakowania
     */
    public void setWielkoscOpakowania(java.lang.String wielkoscOpakowania) {
        this.wielkoscOpakowania = wielkoscOpakowania;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof KomunikatTransakcjaOSPozZapMT)) return false;
        KomunikatTransakcjaOSPozZapMT other = (KomunikatTransakcjaOSPozZapMT) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.dawka==null && other.getDawka()==null) || 
             (this.dawka!=null &&
              this.dawka.equals(other.getDawka()))) &&
            ((this.kodEAN==null && other.getKodEAN()==null) || 
             (this.kodEAN!=null &&
              this.kodEAN.equals(other.getKodEAN()))) &&
            ((this.krajPochodzenia==null && other.getKrajPochodzenia()==null) || 
             (this.krajPochodzenia!=null &&
              this.krajPochodzenia.equals(other.getKrajPochodzenia()))) &&
            ((this.nazwaHandlowa==null && other.getNazwaHandlowa()==null) || 
             (this.nazwaHandlowa!=null &&
              this.nazwaHandlowa.equals(other.getNazwaHandlowa()))) &&
            ((this.nazwaMiedzynarodowa==null && other.getNazwaMiedzynarodowa()==null) || 
             (this.nazwaMiedzynarodowa!=null &&
              this.nazwaMiedzynarodowa.equals(other.getNazwaMiedzynarodowa()))) &&
            ((this.postac==null && other.getPostac()==null) || 
             (this.postac!=null &&
              this.postac.equals(other.getPostac()))) &&
            ((this.producent==null && other.getProducent()==null) || 
             (this.producent!=null &&
              this.producent.equals(other.getProducent()))) &&
            ((this.wielkoscOpakowania==null && other.getWielkoscOpakowania()==null) || 
             (this.wielkoscOpakowania!=null &&
              this.wielkoscOpakowania.equals(other.getWielkoscOpakowania())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDawka() != null) {
            _hashCode += getDawka().hashCode();
        }
        if (getKodEAN() != null) {
            _hashCode += getKodEAN().hashCode();
        }
        if (getKrajPochodzenia() != null) {
            _hashCode += getKrajPochodzenia().hashCode();
        }
        if (getNazwaHandlowa() != null) {
            _hashCode += getNazwaHandlowa().hashCode();
        }
        if (getNazwaMiedzynarodowa() != null) {
            _hashCode += getNazwaMiedzynarodowa().hashCode();
        }
        if (getPostac() != null) {
            _hashCode += getPostac().hashCode();
        }
        if (getProducent() != null) {
            _hashCode += getProducent().hashCode();
        }
        if (getWielkoscOpakowania() != null) {
            _hashCode += getWielkoscOpakowania().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(KomunikatTransakcjaOSPozZapMT.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "KomunikatTransakcjaOSPozZapMT"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dawka");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dawka"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("kodEAN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "kodEAN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("krajPochodzenia");
        elemField.setXmlName(new javax.xml.namespace.QName("", "krajPochodzenia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nazwaHandlowa");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nazwaHandlowa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nazwaMiedzynarodowa");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nazwaMiedzynarodowa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("postac");
        elemField.setXmlName(new javax.xml.namespace.QName("", "postac"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("producent");
        elemField.setXmlName(new javax.xml.namespace.QName("", "producent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wielkoscOpakowania");
        elemField.setXmlName(new javax.xml.namespace.QName("", "wielkoscOpakowania"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
