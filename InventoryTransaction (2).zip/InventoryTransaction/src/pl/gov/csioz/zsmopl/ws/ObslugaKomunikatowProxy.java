package pl.gov.csioz.zsmopl.ws;

public class ObslugaKomunikatowProxy implements pl.gov.csioz.zsmopl.ws.ObslugaKomunikatow {
  private String _endpoint = null;
  private pl.gov.csioz.zsmopl.ws.ObslugaKomunikatow obslugaKomunikatow = null;
  
  public ObslugaKomunikatowProxy() {
    _initObslugaKomunikatowProxy();
  }
  
  public ObslugaKomunikatowProxy(String endpoint) {
    _endpoint = endpoint;
    _initObslugaKomunikatowProxy();
  }
  
  private void _initObslugaKomunikatowProxy() {
    try {
      obslugaKomunikatow = (new pl.gov.csioz.zsmopl.ws.ObslugaKomunikatowServiceLocator()).getObslugaKomunikatowPort();
      if (obslugaKomunikatow != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)obslugaKomunikatow)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)obslugaKomunikatow)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (obslugaKomunikatow != null)
      ((javax.xml.rpc.Stub)obslugaKomunikatow)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public pl.gov.csioz.zsmopl.ws.ObslugaKomunikatow getObslugaKomunikatow() {
    if (obslugaKomunikatow == null)
      _initObslugaKomunikatowProxy();
    return obslugaKomunikatow;
  }
  
  public pl.gov.csioz.zsmopl.mt.IdentyfikatorKomunikatuMT zapiszKomunikatOS(pl.gov.csioz.zsmopl.mt.KomunikatOSMT komunikatOS) throws java.rmi.RemoteException, pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladTworzeniaIdentyfikatoraKomunikatu, pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladDostepnosci{
    if (obslugaKomunikatow == null)
      _initObslugaKomunikatowProxy();
    return obslugaKomunikatow.zapiszKomunikatOS(komunikatOS);
  }
  
  public pl.gov.csioz.zsmopl.mt.IdentyfikatorKomunikatuMT zapiszKomunikatPD(pl.gov.csioz.zsmopl.mt.KomunikatPDMT komunikatPD) throws java.rmi.RemoteException, pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladTworzeniaIdentyfikatoraKomunikatu, pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladDostepnosci{
    if (obslugaKomunikatow == null)
      _initObslugaKomunikatowProxy();
    return obslugaKomunikatow.zapiszKomunikatPD(komunikatPD);
  }
  
  public pl.gov.csioz.zsmopl.mt.IdentyfikatorKomunikatuMT zapiszKomunikatZB(pl.gov.csioz.zsmopl.mt.KomunikatZBMT komunikatZB) throws java.rmi.RemoteException, pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladTworzeniaIdentyfikatoraKomunikatu, pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladDostepnosci{
    if (obslugaKomunikatow == null)
      _initObslugaKomunikatowProxy();
    return obslugaKomunikatow.zapiszKomunikatZB(komunikatZB);
  }
  
  
}