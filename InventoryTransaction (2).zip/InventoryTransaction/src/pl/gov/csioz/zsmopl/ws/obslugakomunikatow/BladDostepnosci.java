/**
 * BladDostepnosci.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package pl.gov.csioz.zsmopl.ws.obslugakomunikatow;

public class BladDostepnosci  extends org.apache.axis.AxisFault  implements java.io.Serializable {
    private pl.gov.csioz.zsmopl.mt.BladDostepnosci bladDostepnosci;

    public BladDostepnosci() {
    }

    public BladDostepnosci(
           pl.gov.csioz.zsmopl.mt.BladDostepnosci bladDostepnosci) {
        this.bladDostepnosci = bladDostepnosci;
    }


    /**
     * Gets the bladDostepnosci value for this BladDostepnosci.
     * 
     * @return bladDostepnosci
     */
    public pl.gov.csioz.zsmopl.mt.BladDostepnosci getBladDostepnosci() {
        return bladDostepnosci;
    }


    /**
     * Sets the bladDostepnosci value for this BladDostepnosci.
     * 
     * @param bladDostepnosci
     */
    public void setBladDostepnosci(pl.gov.csioz.zsmopl.mt.BladDostepnosci bladDostepnosci) {
        this.bladDostepnosci = bladDostepnosci;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BladDostepnosci)) return false;
        BladDostepnosci other = (BladDostepnosci) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.bladDostepnosci==null && other.getBladDostepnosci()==null) || 
             (this.bladDostepnosci!=null &&
              this.bladDostepnosci.equals(other.getBladDostepnosci())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBladDostepnosci() != null) {
            _hashCode += getBladDostepnosci().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BladDostepnosci.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/ws/obslugakomunikatow/", ">bladDostepnosci"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bladDostepnosci");
        elemField.setXmlName(new javax.xml.namespace.QName("", "bladDostepnosci"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "BladDostepnosci"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }


    /**
     * Writes the exception data to the faultDetails
     */
    public void writeDetails(javax.xml.namespace.QName qname, org.apache.axis.encoding.SerializationContext context) throws java.io.IOException {
        context.serialize(qname, null, this);
    }
}
