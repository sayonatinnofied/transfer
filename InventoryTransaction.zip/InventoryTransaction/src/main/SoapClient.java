package main;

import javax.xml.soap.*;
import org.apache.xml.security.signature.*;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.transforms.*;
import javax.xml.namespace.QName;
import javax.xml.parsers.*;
import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import org.w3c.dom.Document;
import org.xml.sax.*;


public class SoapClient {

	// SAAJ - SOAP Client Testing
		@SuppressWarnings("resource")
		public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException, KeyStoreException, NoSuchAlgorithmException, CertificateException, UnrecoverableKeyException {
				// Initialize the library
	      		org.apache.xml.security.Init.init();

				// Reading XML file
				File fXmlFile = new File("D:/AbbVie/Users/Input.xml");
				
				//Converting file to string
				BufferedReader br = new BufferedReader(new FileReader(fXmlFile));
				String line;
				StringBuilder sb = new StringBuilder();
				while((line=br.readLine())!= null){
				    sb.append(line.trim());
				}	
				String requestXML=sb.toString();
				System.out.println(requestXML);
				
				
		        String soapEndpointUrl = "https://ewa-zsmopl.ezdrowie.gov.pl/cxf/zsmopl/ws/";
		        String soapAction = "http://csioz.gov.pl/zsmopl/ws/zapiszKomunikatOS";
		        
       
		        //Calling WebService
		        callSoapWebService(soapEndpointUrl, soapAction, requestXML);	      
		    }

		    private static void callSoapWebService(String soapEndpointUrl, String soapAction,String requestXML) {
		        try {
		            // Create SOAP Connection
		            SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
		            SOAPConnection soapConnection = soapConnectionFactory.createConnection();

		            // Send SOAP Message to SOAP Server
		            SOAPMessage soapResponse = soapConnection.call(createSOAPRequest(soapAction,requestXML), soapEndpointUrl);

		            // Print the SOAP Response
		            System.out.println("Response SOAP Message:");
		            soapResponse.writeTo(System.out);
		            System.out.println();

		            soapConnection.close();
		        } catch (Exception e) {
		            System.err.println("\nError occurred while sending SOAP Request to Server!\nError Details: \n");
		            e.printStackTrace();
		        }
		    }

		   
		    private static SOAPMessage createSOAPRequest(String soapAction, String requestXML) throws SOAPException, ParserConfigurationException, SAXException, IOException, XMLSecurityException, KeyStoreException, NoSuchAlgorithmException, CertificateException, UnrecoverableKeyException{
		        
		    	
		    	//Create SOAP Message
		    	 MessageFactory messageFactory = MessageFactory.newInstance();
			     SOAPMessage soapMessage = messageFactory.createMessage();
			     		    	
		    	//Converting XMLString to Doc
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		        dbFactory.setNamespaceAware(true);
		        dbFactory.setAttribute("http://xml.org/sax/features/namespaces", Boolean.TRUE);
		        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

		        InputSource is = new InputSource();
		        is.setCharacterStream(new StringReader(requestXML));
		        Document xmlDocument = dBuilder.parse(is);
		    	
		        
				//Creating SOAP-Part
		        SOAPPart soapPart = soapMessage.getSOAPPart();

		        String obs = "obs";
		        String obsURI = "http://csioz.gov.pl/zsmopl/ws/obslugakomunikatow/";		        
		       
		        
		        // SOAP Envelope
		        SOAPEnvelope envelope = soapPart.getEnvelope();
		        envelope.addNamespaceDeclaration(obs, obsURI);
		        
		        //SOAP Body
		        SOAPBody soapBody = envelope.getBody();
		        soapBody.addDocument(xmlDocument);
		        
		        
		       	//SOAP Header	        
		        SOAPHeader header = envelope.getHeader();
		        SOAPElement security = header.addChildElement("Security", "wsse", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd");
		        
		        //SOAPElement usernameToken =security.addChildElement("UsernameToken", "wsse");
		        security.setAttribute("SOAP-ENV:mustUnderstand", "1");
		        
                security.addAttribute(new QName("xmlns:wsu"), "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd");
                
                SOAPElement BinarySecurityToken = security.addChildElement("BinarySecurityToken", "wsse");
                
                BinarySecurityToken.setAttribute("EncodingType","http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary" );
                BinarySecurityToken.setAttribute("ValueType","http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-x509-token-profile-1.0#X509PKIPathv1");
                                              
                
                //Adding KeyStore
		        FileInputStream fis = new FileInputStream("D:/AbbVie/Users/AbbVieKeyStore3.jks");
		        String keystoreType = "JKS";
		        String keystorePass = "abbvie11";
		        KeyStore ks = KeyStore.getInstance(keystoreType); 
		        ks.load(fis, keystorePass.toCharArray());
		        
		        //Get the private key that will be used to sign the request
		        String privateKeyAlias = "aliasbrejentkey";
		        String privateKeyPass = "abbvie11";
		        PrivateKey privateKey = (PrivateKey) ks.getKey(privateKeyAlias,privateKeyPass.toCharArray());
		        
		        		        
		        // Create an XMLSignature instance       
		        XMLSignature sig = new XMLSignature(xmlDocument,"",XMLSignature.ALGO_ID_SIGNATURE_RSA_SHA1);
		        
		        //Adding signature to security
		        security.appendChild(sig.getElement());
		        
		        // Specify the transforms
		        Transforms transforms = new Transforms(xmlDocument);
		        transforms.addTransform(Transforms.TRANSFORM_ENVELOPED_SIGNATURE);
		        transforms.addTransform(Transforms.TRANSFORM_C14N_EXCL_OMIT_COMMENTS);
		        sig.addDocument("", transforms, org.apache.xml.security.utils.Constants.ALGO_ID_DIGEST_SHA1);
		        
		        
		        //signing with PrivateKey
		        String certificateAlias = "aliasbrejentkey";
		        X509Certificate cert = (X509Certificate) ks.getCertificate(certificateAlias);
		        	      sig.addKeyInfo(cert);
		        	      sig.addKeyInfo(cert.getPublicKey());
		        	      System.out.println("Starting to sign SOAP Request");
		        	      sig.sign(privateKey);
		        	      System.out.println("Finished signing");
		        
		        //adding SoapAction and Signature	      
                header.setAttribute("SOAPAction", soapAction);
                System.out.println(sig.getBaseNamespace());
                soapMessage.saveChanges();
                
		       		        
		        /* Print the request message, just for debugging purposes */
		        System.out.println("Request SOAP Message:");
		        soapMessage.writeTo(System.out);
		        System.out.println("\n");
				
		        return soapMessage;
		        
		    }
	}