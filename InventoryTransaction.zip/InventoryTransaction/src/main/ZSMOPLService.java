package main;

import java.rmi.RemoteException;

import pl.gov.csioz.zsmopl.mt.IdentyfikatorKomunikatuMT;
import pl.gov.csioz.zsmopl.mt.KomunikatOSMT;
import pl.gov.csioz.zsmopl.mt.KomunikatPDMT;
import pl.gov.csioz.zsmopl.mt.KomunikatZBMT;
import pl.gov.csioz.zsmopl.ws.ObslugaKomunikatowProxy;
import pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladDostepnosci;
import pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladTworzeniaIdentyfikatoraKomunikatu;

public class ZSMOPLService {

	private ObslugaKomunikatowProxy proxyCall = null;

	public ZSMOPLService() {
		this.proxyCall = new ObslugaKomunikatowProxy();
		
		// ADD THE KEY STORE PART HERE
	}

	public IdentyfikatorKomunikatuMT zapiszKomunikatPD(KomunikatPDMT komunikatPDMTObj)
			throws BladTworzeniaIdentyfikatoraKomunikatu, BladDostepnosci, RemoteException {
		return this.proxyCall.zapiszKomunikatPD(komunikatPDMTObj);

	}

	public IdentyfikatorKomunikatuMT zapiszKomunikatOS(KomunikatOSMT komunikatOSMTObj)
			throws BladTworzeniaIdentyfikatoraKomunikatu, BladDostepnosci, RemoteException {
		return this.proxyCall.zapiszKomunikatOS(komunikatOSMTObj);
	}
	
	public IdentyfikatorKomunikatuMT zapiszKomunikatZB(KomunikatZBMT komunikatZBMTObj)
			throws BladTworzeniaIdentyfikatoraKomunikatu, BladDostepnosci, RemoteException {
		return this.proxyCall.zapiszKomunikatZB(komunikatZBMTObj);
	}
}
