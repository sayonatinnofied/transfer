/**
 * IdentyfikatorMPDPodmiotuDrugaStronaMT.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package pl.gov.csioz.zsmopl.mt;


/**
 * Identyfikator miejsca prowadzenia działalności podmiotu raportujacego.
 */
public class IdentyfikatorMPDPodmiotuDrugaStronaMT  implements java.io.Serializable {
    private java.lang.String idBiznesowy;

    private java.lang.String rodzajMPDPodmiotuRaportujacego;

    public IdentyfikatorMPDPodmiotuDrugaStronaMT() {
    }

    public IdentyfikatorMPDPodmiotuDrugaStronaMT(
           java.lang.String idBiznesowy,
           java.lang.String rodzajMPDPodmiotuRaportujacego) {
           this.idBiznesowy = idBiznesowy;
           this.rodzajMPDPodmiotuRaportujacego = rodzajMPDPodmiotuRaportujacego;
    }


    /**
     * Gets the idBiznesowy value for this IdentyfikatorMPDPodmiotuDrugaStronaMT.
     * 
     * @return idBiznesowy
     */
    public java.lang.String getIdBiznesowy() {
        return idBiznesowy;
    }


    /**
     * Sets the idBiznesowy value for this IdentyfikatorMPDPodmiotuDrugaStronaMT.
     * 
     * @param idBiznesowy
     */
    public void setIdBiznesowy(java.lang.String idBiznesowy) {
        this.idBiznesowy = idBiznesowy;
    }


    /**
     * Gets the rodzajMPDPodmiotuRaportujacego value for this IdentyfikatorMPDPodmiotuDrugaStronaMT.
     * 
     * @return rodzajMPDPodmiotuRaportujacego
     */
    public java.lang.String getRodzajMPDPodmiotuRaportujacego() {
        return rodzajMPDPodmiotuRaportujacego;
    }


    /**
     * Sets the rodzajMPDPodmiotuRaportujacego value for this IdentyfikatorMPDPodmiotuDrugaStronaMT.
     * 
     * @param rodzajMPDPodmiotuRaportujacego
     */
    public void setRodzajMPDPodmiotuRaportujacego(java.lang.String rodzajMPDPodmiotuRaportujacego) {
        this.rodzajMPDPodmiotuRaportujacego = rodzajMPDPodmiotuRaportujacego;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IdentyfikatorMPDPodmiotuDrugaStronaMT)) return false;
        IdentyfikatorMPDPodmiotuDrugaStronaMT other = (IdentyfikatorMPDPodmiotuDrugaStronaMT) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.idBiznesowy==null && other.getIdBiznesowy()==null) || 
             (this.idBiznesowy!=null &&
              this.idBiznesowy.equals(other.getIdBiznesowy()))) &&
            ((this.rodzajMPDPodmiotuRaportujacego==null && other.getRodzajMPDPodmiotuRaportujacego()==null) || 
             (this.rodzajMPDPodmiotuRaportujacego!=null &&
              this.rodzajMPDPodmiotuRaportujacego.equals(other.getRodzajMPDPodmiotuRaportujacego())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIdBiznesowy() != null) {
            _hashCode += getIdBiznesowy().hashCode();
        }
        if (getRodzajMPDPodmiotuRaportujacego() != null) {
            _hashCode += getRodzajMPDPodmiotuRaportujacego().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IdentyfikatorMPDPodmiotuDrugaStronaMT.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "IdentyfikatorMPDPodmiotuDrugaStronaMT"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idBiznesowy");
        elemField.setXmlName(new javax.xml.namespace.QName("", "idBiznesowy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rodzajMPDPodmiotuRaportujacego");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rodzajMPDPodmiotuRaportujacego"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
