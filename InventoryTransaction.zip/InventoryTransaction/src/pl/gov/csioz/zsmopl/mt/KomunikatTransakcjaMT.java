/**
 * KomunikatTransakcjaMT.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package pl.gov.csioz.zsmopl.mt;


/**
 * Struktura odpowiada przesyłanym przez podmioty raportujące transakcjom
 * w ramach
 *                 komunikatów.
 */
public class KomunikatTransakcjaMT  implements java.io.Serializable {
    private java.util.Calendar dataCzasTransakcji;

    private java.math.BigInteger lp;

    public KomunikatTransakcjaMT() {
    }

    public KomunikatTransakcjaMT(
           java.util.Calendar dataCzasTransakcji,
           java.math.BigInteger lp) {
           this.dataCzasTransakcji = dataCzasTransakcji;
           this.lp = lp;
    }


    /**
     * Gets the dataCzasTransakcji value for this KomunikatTransakcjaMT.
     * 
     * @return dataCzasTransakcji
     */
    public java.util.Calendar getDataCzasTransakcji() {
        return dataCzasTransakcji;
    }


    /**
     * Sets the dataCzasTransakcji value for this KomunikatTransakcjaMT.
     * 
     * @param dataCzasTransakcji
     */
    public void setDataCzasTransakcji(java.util.Calendar dataCzasTransakcji) {
        this.dataCzasTransakcji = dataCzasTransakcji;
    }


    /**
     * Gets the lp value for this KomunikatTransakcjaMT.
     * 
     * @return lp
     */
    public java.math.BigInteger getLp() {
        return lp;
    }


    /**
     * Sets the lp value for this KomunikatTransakcjaMT.
     * 
     * @param lp
     */
    public void setLp(java.math.BigInteger lp) {
        this.lp = lp;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof KomunikatTransakcjaMT)) return false;
        KomunikatTransakcjaMT other = (KomunikatTransakcjaMT) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.dataCzasTransakcji==null && other.getDataCzasTransakcji()==null) || 
             (this.dataCzasTransakcji!=null &&
              this.dataCzasTransakcji.equals(other.getDataCzasTransakcji()))) &&
            ((this.lp==null && other.getLp()==null) || 
             (this.lp!=null &&
              this.lp.equals(other.getLp())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDataCzasTransakcji() != null) {
            _hashCode += getDataCzasTransakcji().hashCode();
        }
        if (getLp() != null) {
            _hashCode += getLp().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(KomunikatTransakcjaMT.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "KomunikatTransakcjaMT"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataCzasTransakcji");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dataCzasTransakcji"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lp");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
