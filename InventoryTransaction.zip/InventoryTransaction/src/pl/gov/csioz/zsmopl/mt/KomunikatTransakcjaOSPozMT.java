/**
 * KomunikatTransakcjaOSPozMT.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package pl.gov.csioz.zsmopl.mt;


/**
 * Klasa pozycji dokumentu, który jest transakcją obrotu i stanów.
 * Z jednym obiektem 
 *                 KomunikatTransakcjaOSMT związanych jest - jedna lub
 * więcej pozycji (odpowiadają pozycjom z dokumentu 
 *                 źródłowego transakcji).
 */
public class KomunikatTransakcjaOSPozMT  implements java.io.Serializable {
    private int czyDotImportuDocelInterw;

    private int czyProduktWydanyZRefundacja;

    private java.math.BigDecimal ilosc;

    private java.math.BigDecimal iloscPoKorekcie;

    private java.math.BigDecimal iloscPrzedKorekta;

    private java.lang.String kodEAN;

    private java.math.BigInteger lp;

    private int nrPozycjiDokZrodl;

    private java.lang.String nrZapotrzImportuDocelInterw;

    private java.lang.String przyczynaKorekty;

    private java.lang.String seria;

    private java.math.BigDecimal wartosc;

    private java.math.BigDecimal wartoscPoKorekcie;

    private java.math.BigDecimal wartoscPrzedKorekta;

    private pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaOSPozStanMT komunikatTransakcjaOSPozStanMT;

    private pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaOSPozZapMT komunikatTransakcjaOSPozZapMT;

    public KomunikatTransakcjaOSPozMT() {
    }

    public KomunikatTransakcjaOSPozMT(
           int czyDotImportuDocelInterw,
           int czyProduktWydanyZRefundacja,
           java.math.BigDecimal ilosc,
           java.math.BigDecimal iloscPoKorekcie,
           java.math.BigDecimal iloscPrzedKorekta,
           java.lang.String kodEAN,
           java.math.BigInteger lp,
           int nrPozycjiDokZrodl,
           java.lang.String nrZapotrzImportuDocelInterw,
           java.lang.String przyczynaKorekty,
           java.lang.String seria,
           java.math.BigDecimal wartosc,
           java.math.BigDecimal wartoscPoKorekcie,
           java.math.BigDecimal wartoscPrzedKorekta,
           pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaOSPozStanMT komunikatTransakcjaOSPozStanMT,
           pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaOSPozZapMT komunikatTransakcjaOSPozZapMT) {
           this.czyDotImportuDocelInterw = czyDotImportuDocelInterw;
           this.czyProduktWydanyZRefundacja = czyProduktWydanyZRefundacja;
           this.ilosc = ilosc;
           this.iloscPoKorekcie = iloscPoKorekcie;
           this.iloscPrzedKorekta = iloscPrzedKorekta;
           this.kodEAN = kodEAN;
           this.lp = lp;
           this.nrPozycjiDokZrodl = nrPozycjiDokZrodl;
           this.nrZapotrzImportuDocelInterw = nrZapotrzImportuDocelInterw;
           this.przyczynaKorekty = przyczynaKorekty;
           this.seria = seria;
           this.wartosc = wartosc;
           this.wartoscPoKorekcie = wartoscPoKorekcie;
           this.wartoscPrzedKorekta = wartoscPrzedKorekta;
           this.komunikatTransakcjaOSPozStanMT = komunikatTransakcjaOSPozStanMT;
           this.komunikatTransakcjaOSPozZapMT = komunikatTransakcjaOSPozZapMT;
    }


    /**
     * Gets the czyDotImportuDocelInterw value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return czyDotImportuDocelInterw
     */
    public int getCzyDotImportuDocelInterw() {
        return czyDotImportuDocelInterw;
    }


    /**
     * Sets the czyDotImportuDocelInterw value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param czyDotImportuDocelInterw
     */
    public void setCzyDotImportuDocelInterw(int czyDotImportuDocelInterw) {
        this.czyDotImportuDocelInterw = czyDotImportuDocelInterw;
    }


    /**
     * Gets the czyProduktWydanyZRefundacja value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return czyProduktWydanyZRefundacja
     */
    public int getCzyProduktWydanyZRefundacja() {
        return czyProduktWydanyZRefundacja;
    }


    /**
     * Sets the czyProduktWydanyZRefundacja value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param czyProduktWydanyZRefundacja
     */
    public void setCzyProduktWydanyZRefundacja(int czyProduktWydanyZRefundacja) {
        this.czyProduktWydanyZRefundacja = czyProduktWydanyZRefundacja;
    }


    /**
     * Gets the ilosc value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return ilosc
     */
    public java.math.BigDecimal getIlosc() {
        return ilosc;
    }


    /**
     * Sets the ilosc value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param ilosc
     */
    public void setIlosc(java.math.BigDecimal ilosc) {
        this.ilosc = ilosc;
    }


    /**
     * Gets the iloscPoKorekcie value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return iloscPoKorekcie
     */
    public java.math.BigDecimal getIloscPoKorekcie() {
        return iloscPoKorekcie;
    }


    /**
     * Sets the iloscPoKorekcie value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param iloscPoKorekcie
     */
    public void setIloscPoKorekcie(java.math.BigDecimal iloscPoKorekcie) {
        this.iloscPoKorekcie = iloscPoKorekcie;
    }


    /**
     * Gets the iloscPrzedKorekta value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return iloscPrzedKorekta
     */
    public java.math.BigDecimal getIloscPrzedKorekta() {
        return iloscPrzedKorekta;
    }


    /**
     * Sets the iloscPrzedKorekta value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param iloscPrzedKorekta
     */
    public void setIloscPrzedKorekta(java.math.BigDecimal iloscPrzedKorekta) {
        this.iloscPrzedKorekta = iloscPrzedKorekta;
    }


    /**
     * Gets the kodEAN value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return kodEAN
     */
    public java.lang.String getKodEAN() {
        return kodEAN;
    }


    /**
     * Sets the kodEAN value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param kodEAN
     */
    public void setKodEAN(java.lang.String kodEAN) {
        this.kodEAN = kodEAN;
    }


    /**
     * Gets the lp value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return lp
     */
    public java.math.BigInteger getLp() {
        return lp;
    }


    /**
     * Sets the lp value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param lp
     */
    public void setLp(java.math.BigInteger lp) {
        this.lp = lp;
    }


    /**
     * Gets the nrPozycjiDokZrodl value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return nrPozycjiDokZrodl
     */
    public int getNrPozycjiDokZrodl() {
        return nrPozycjiDokZrodl;
    }


    /**
     * Sets the nrPozycjiDokZrodl value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param nrPozycjiDokZrodl
     */
    public void setNrPozycjiDokZrodl(int nrPozycjiDokZrodl) {
        this.nrPozycjiDokZrodl = nrPozycjiDokZrodl;
    }


    /**
     * Gets the nrZapotrzImportuDocelInterw value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return nrZapotrzImportuDocelInterw
     */
    public java.lang.String getNrZapotrzImportuDocelInterw() {
        return nrZapotrzImportuDocelInterw;
    }


    /**
     * Sets the nrZapotrzImportuDocelInterw value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param nrZapotrzImportuDocelInterw
     */
    public void setNrZapotrzImportuDocelInterw(java.lang.String nrZapotrzImportuDocelInterw) {
        this.nrZapotrzImportuDocelInterw = nrZapotrzImportuDocelInterw;
    }


    /**
     * Gets the przyczynaKorekty value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return przyczynaKorekty
     */
    public java.lang.String getPrzyczynaKorekty() {
        return przyczynaKorekty;
    }


    /**
     * Sets the przyczynaKorekty value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param przyczynaKorekty
     */
    public void setPrzyczynaKorekty(java.lang.String przyczynaKorekty) {
        this.przyczynaKorekty = przyczynaKorekty;
    }


    /**
     * Gets the seria value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return seria
     */
    public java.lang.String getSeria() {
        return seria;
    }


    /**
     * Sets the seria value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param seria
     */
    public void setSeria(java.lang.String seria) {
        this.seria = seria;
    }


    /**
     * Gets the wartosc value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return wartosc
     */
    public java.math.BigDecimal getWartosc() {
        return wartosc;
    }


    /**
     * Sets the wartosc value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param wartosc
     */
    public void setWartosc(java.math.BigDecimal wartosc) {
        this.wartosc = wartosc;
    }


    /**
     * Gets the wartoscPoKorekcie value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return wartoscPoKorekcie
     */
    public java.math.BigDecimal getWartoscPoKorekcie() {
        return wartoscPoKorekcie;
    }


    /**
     * Sets the wartoscPoKorekcie value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param wartoscPoKorekcie
     */
    public void setWartoscPoKorekcie(java.math.BigDecimal wartoscPoKorekcie) {
        this.wartoscPoKorekcie = wartoscPoKorekcie;
    }


    /**
     * Gets the wartoscPrzedKorekta value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return wartoscPrzedKorekta
     */
    public java.math.BigDecimal getWartoscPrzedKorekta() {
        return wartoscPrzedKorekta;
    }


    /**
     * Sets the wartoscPrzedKorekta value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param wartoscPrzedKorekta
     */
    public void setWartoscPrzedKorekta(java.math.BigDecimal wartoscPrzedKorekta) {
        this.wartoscPrzedKorekta = wartoscPrzedKorekta;
    }


    /**
     * Gets the komunikatTransakcjaOSPozStanMT value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return komunikatTransakcjaOSPozStanMT
     */
    public pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaOSPozStanMT getKomunikatTransakcjaOSPozStanMT() {
        return komunikatTransakcjaOSPozStanMT;
    }


    /**
     * Sets the komunikatTransakcjaOSPozStanMT value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param komunikatTransakcjaOSPozStanMT
     */
    public void setKomunikatTransakcjaOSPozStanMT(pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaOSPozStanMT komunikatTransakcjaOSPozStanMT) {
        this.komunikatTransakcjaOSPozStanMT = komunikatTransakcjaOSPozStanMT;
    }


    /**
     * Gets the komunikatTransakcjaOSPozZapMT value for this KomunikatTransakcjaOSPozMT.
     * 
     * @return komunikatTransakcjaOSPozZapMT
     */
    public pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaOSPozZapMT getKomunikatTransakcjaOSPozZapMT() {
        return komunikatTransakcjaOSPozZapMT;
    }


    /**
     * Sets the komunikatTransakcjaOSPozZapMT value for this KomunikatTransakcjaOSPozMT.
     * 
     * @param komunikatTransakcjaOSPozZapMT
     */
    public void setKomunikatTransakcjaOSPozZapMT(pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaOSPozZapMT komunikatTransakcjaOSPozZapMT) {
        this.komunikatTransakcjaOSPozZapMT = komunikatTransakcjaOSPozZapMT;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof KomunikatTransakcjaOSPozMT)) return false;
        KomunikatTransakcjaOSPozMT other = (KomunikatTransakcjaOSPozMT) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.czyDotImportuDocelInterw == other.getCzyDotImportuDocelInterw() &&
            this.czyProduktWydanyZRefundacja == other.getCzyProduktWydanyZRefundacja() &&
            ((this.ilosc==null && other.getIlosc()==null) || 
             (this.ilosc!=null &&
              this.ilosc.equals(other.getIlosc()))) &&
            ((this.iloscPoKorekcie==null && other.getIloscPoKorekcie()==null) || 
             (this.iloscPoKorekcie!=null &&
              this.iloscPoKorekcie.equals(other.getIloscPoKorekcie()))) &&
            ((this.iloscPrzedKorekta==null && other.getIloscPrzedKorekta()==null) || 
             (this.iloscPrzedKorekta!=null &&
              this.iloscPrzedKorekta.equals(other.getIloscPrzedKorekta()))) &&
            ((this.kodEAN==null && other.getKodEAN()==null) || 
             (this.kodEAN!=null &&
              this.kodEAN.equals(other.getKodEAN()))) &&
            ((this.lp==null && other.getLp()==null) || 
             (this.lp!=null &&
              this.lp.equals(other.getLp()))) &&
            this.nrPozycjiDokZrodl == other.getNrPozycjiDokZrodl() &&
            ((this.nrZapotrzImportuDocelInterw==null && other.getNrZapotrzImportuDocelInterw()==null) || 
             (this.nrZapotrzImportuDocelInterw!=null &&
              this.nrZapotrzImportuDocelInterw.equals(other.getNrZapotrzImportuDocelInterw()))) &&
            ((this.przyczynaKorekty==null && other.getPrzyczynaKorekty()==null) || 
             (this.przyczynaKorekty!=null &&
              this.przyczynaKorekty.equals(other.getPrzyczynaKorekty()))) &&
            ((this.seria==null && other.getSeria()==null) || 
             (this.seria!=null &&
              this.seria.equals(other.getSeria()))) &&
            ((this.wartosc==null && other.getWartosc()==null) || 
             (this.wartosc!=null &&
              this.wartosc.equals(other.getWartosc()))) &&
            ((this.wartoscPoKorekcie==null && other.getWartoscPoKorekcie()==null) || 
             (this.wartoscPoKorekcie!=null &&
              this.wartoscPoKorekcie.equals(other.getWartoscPoKorekcie()))) &&
            ((this.wartoscPrzedKorekta==null && other.getWartoscPrzedKorekta()==null) || 
             (this.wartoscPrzedKorekta!=null &&
              this.wartoscPrzedKorekta.equals(other.getWartoscPrzedKorekta()))) &&
            ((this.komunikatTransakcjaOSPozStanMT==null && other.getKomunikatTransakcjaOSPozStanMT()==null) || 
             (this.komunikatTransakcjaOSPozStanMT!=null &&
              this.komunikatTransakcjaOSPozStanMT.equals(other.getKomunikatTransakcjaOSPozStanMT()))) &&
            ((this.komunikatTransakcjaOSPozZapMT==null && other.getKomunikatTransakcjaOSPozZapMT()==null) || 
             (this.komunikatTransakcjaOSPozZapMT!=null &&
              this.komunikatTransakcjaOSPozZapMT.equals(other.getKomunikatTransakcjaOSPozZapMT())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getCzyDotImportuDocelInterw();
        _hashCode += getCzyProduktWydanyZRefundacja();
        if (getIlosc() != null) {
            _hashCode += getIlosc().hashCode();
        }
        if (getIloscPoKorekcie() != null) {
            _hashCode += getIloscPoKorekcie().hashCode();
        }
        if (getIloscPrzedKorekta() != null) {
            _hashCode += getIloscPrzedKorekta().hashCode();
        }
        if (getKodEAN() != null) {
            _hashCode += getKodEAN().hashCode();
        }
        if (getLp() != null) {
            _hashCode += getLp().hashCode();
        }
        _hashCode += getNrPozycjiDokZrodl();
        if (getNrZapotrzImportuDocelInterw() != null) {
            _hashCode += getNrZapotrzImportuDocelInterw().hashCode();
        }
        if (getPrzyczynaKorekty() != null) {
            _hashCode += getPrzyczynaKorekty().hashCode();
        }
        if (getSeria() != null) {
            _hashCode += getSeria().hashCode();
        }
        if (getWartosc() != null) {
            _hashCode += getWartosc().hashCode();
        }
        if (getWartoscPoKorekcie() != null) {
            _hashCode += getWartoscPoKorekcie().hashCode();
        }
        if (getWartoscPrzedKorekta() != null) {
            _hashCode += getWartoscPrzedKorekta().hashCode();
        }
        if (getKomunikatTransakcjaOSPozStanMT() != null) {
            _hashCode += getKomunikatTransakcjaOSPozStanMT().hashCode();
        }
        if (getKomunikatTransakcjaOSPozZapMT() != null) {
            _hashCode += getKomunikatTransakcjaOSPozZapMT().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(KomunikatTransakcjaOSPozMT.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "KomunikatTransakcjaOSPozMT"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("czyDotImportuDocelInterw");
        elemField.setXmlName(new javax.xml.namespace.QName("", "czyDotImportuDocelInterw"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("czyProduktWydanyZRefundacja");
        elemField.setXmlName(new javax.xml.namespace.QName("", "czyProduktWydanyZRefundacja"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ilosc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ilosc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("iloscPoKorekcie");
        elemField.setXmlName(new javax.xml.namespace.QName("", "iloscPoKorekcie"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("iloscPrzedKorekta");
        elemField.setXmlName(new javax.xml.namespace.QName("", "iloscPrzedKorekta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("kodEAN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "kodEAN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lp");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nrPozycjiDokZrodl");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nrPozycjiDokZrodl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nrZapotrzImportuDocelInterw");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nrZapotrzImportuDocelInterw"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("przyczynaKorekty");
        elemField.setXmlName(new javax.xml.namespace.QName("", "przyczynaKorekty"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("seria");
        elemField.setXmlName(new javax.xml.namespace.QName("", "seria"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wartosc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "wartosc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wartoscPoKorekcie");
        elemField.setXmlName(new javax.xml.namespace.QName("", "wartoscPoKorekcie"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wartoscPrzedKorekta");
        elemField.setXmlName(new javax.xml.namespace.QName("", "wartoscPrzedKorekta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("komunikatTransakcjaOSPozStanMT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "komunikatTransakcjaOSPozStanMT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "KomunikatTransakcjaOSPozStanMT"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("komunikatTransakcjaOSPozZapMT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "komunikatTransakcjaOSPozZapMT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "KomunikatTransakcjaOSPozZapMT"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
