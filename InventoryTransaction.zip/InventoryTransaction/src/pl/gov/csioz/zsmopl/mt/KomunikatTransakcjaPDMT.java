/**
 * KomunikatTransakcjaPDMT.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package pl.gov.csioz.zsmopl.mt;


/**
 * Transakcja planowania dostaw produktu leczniczego.
 */
public class KomunikatTransakcjaPDMT  extends pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaMT  implements java.io.Serializable {
    private java.util.Date dataKoncowa;

    private java.util.Date dataPoczatkowa;

    private java.lang.String kodEAN;

    private pl.gov.csioz.zsmopl.mt.RodzajTransPlanDostawMT rodzajTransakcji;

    private java.lang.String uzasadnWstrzymZakoncz;

    private pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaPDPlanMT[] komunikatTransakcjaPDPlan;

    public KomunikatTransakcjaPDMT() {
    }

    public KomunikatTransakcjaPDMT(
           java.util.Calendar dataCzasTransakcji,
           java.math.BigInteger lp,
           java.util.Date dataKoncowa,
           java.util.Date dataPoczatkowa,
           java.lang.String kodEAN,
           pl.gov.csioz.zsmopl.mt.RodzajTransPlanDostawMT rodzajTransakcji,
           java.lang.String uzasadnWstrzymZakoncz,
           pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaPDPlanMT[] komunikatTransakcjaPDPlan) {
        super(
            dataCzasTransakcji,
            lp);
        this.dataKoncowa = dataKoncowa;
        this.dataPoczatkowa = dataPoczatkowa;
        this.kodEAN = kodEAN;
        this.rodzajTransakcji = rodzajTransakcji;
        this.uzasadnWstrzymZakoncz = uzasadnWstrzymZakoncz;
        this.komunikatTransakcjaPDPlan = komunikatTransakcjaPDPlan;
    }


    /**
     * Gets the dataKoncowa value for this KomunikatTransakcjaPDMT.
     * 
     * @return dataKoncowa
     */
    public java.util.Date getDataKoncowa() {
        return dataKoncowa;
    }


    /**
     * Sets the dataKoncowa value for this KomunikatTransakcjaPDMT.
     * 
     * @param dataKoncowa
     */
    public void setDataKoncowa(java.util.Date dataKoncowa) {
        this.dataKoncowa = dataKoncowa;
    }


    /**
     * Gets the dataPoczatkowa value for this KomunikatTransakcjaPDMT.
     * 
     * @return dataPoczatkowa
     */
    public java.util.Date getDataPoczatkowa() {
        return dataPoczatkowa;
    }


    /**
     * Sets the dataPoczatkowa value for this KomunikatTransakcjaPDMT.
     * 
     * @param dataPoczatkowa
     */
    public void setDataPoczatkowa(java.util.Date dataPoczatkowa) {
        this.dataPoczatkowa = dataPoczatkowa;
    }


    /**
     * Gets the kodEAN value for this KomunikatTransakcjaPDMT.
     * 
     * @return kodEAN
     */
    public java.lang.String getKodEAN() {
        return kodEAN;
    }


    /**
     * Sets the kodEAN value for this KomunikatTransakcjaPDMT.
     * 
     * @param kodEAN
     */
    public void setKodEAN(java.lang.String kodEAN) {
        this.kodEAN = kodEAN;
    }


    /**
     * Gets the rodzajTransakcji value for this KomunikatTransakcjaPDMT.
     * 
     * @return rodzajTransakcji
     */
    public pl.gov.csioz.zsmopl.mt.RodzajTransPlanDostawMT getRodzajTransakcji() {
        return rodzajTransakcji;
    }


    /**
     * Sets the rodzajTransakcji value for this KomunikatTransakcjaPDMT.
     * 
     * @param rodzajTransakcji
     */
    public void setRodzajTransakcji(pl.gov.csioz.zsmopl.mt.RodzajTransPlanDostawMT rodzajTransakcji) {
        this.rodzajTransakcji = rodzajTransakcji;
    }


    /**
     * Gets the uzasadnWstrzymZakoncz value for this KomunikatTransakcjaPDMT.
     * 
     * @return uzasadnWstrzymZakoncz
     */
    public java.lang.String getUzasadnWstrzymZakoncz() {
        return uzasadnWstrzymZakoncz;
    }


    /**
     * Sets the uzasadnWstrzymZakoncz value for this KomunikatTransakcjaPDMT.
     * 
     * @param uzasadnWstrzymZakoncz
     */
    public void setUzasadnWstrzymZakoncz(java.lang.String uzasadnWstrzymZakoncz) {
        this.uzasadnWstrzymZakoncz = uzasadnWstrzymZakoncz;
    }


    /**
     * Gets the komunikatTransakcjaPDPlan value for this KomunikatTransakcjaPDMT.
     * 
     * @return komunikatTransakcjaPDPlan
     */
    public pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaPDPlanMT[] getKomunikatTransakcjaPDPlan() {
        return komunikatTransakcjaPDPlan;
    }


    /**
     * Sets the komunikatTransakcjaPDPlan value for this KomunikatTransakcjaPDMT.
     * 
     * @param komunikatTransakcjaPDPlan
     */
    public void setKomunikatTransakcjaPDPlan(pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaPDPlanMT[] komunikatTransakcjaPDPlan) {
        this.komunikatTransakcjaPDPlan = komunikatTransakcjaPDPlan;
    }

    public pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaPDPlanMT getKomunikatTransakcjaPDPlan(int i) {
        return this.komunikatTransakcjaPDPlan[i];
    }

    public void setKomunikatTransakcjaPDPlan(int i, pl.gov.csioz.zsmopl.mt.KomunikatTransakcjaPDPlanMT _value) {
        this.komunikatTransakcjaPDPlan[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof KomunikatTransakcjaPDMT)) return false;
        KomunikatTransakcjaPDMT other = (KomunikatTransakcjaPDMT) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.dataKoncowa==null && other.getDataKoncowa()==null) || 
             (this.dataKoncowa!=null &&
              this.dataKoncowa.equals(other.getDataKoncowa()))) &&
            ((this.dataPoczatkowa==null && other.getDataPoczatkowa()==null) || 
             (this.dataPoczatkowa!=null &&
              this.dataPoczatkowa.equals(other.getDataPoczatkowa()))) &&
            ((this.kodEAN==null && other.getKodEAN()==null) || 
             (this.kodEAN!=null &&
              this.kodEAN.equals(other.getKodEAN()))) &&
            ((this.rodzajTransakcji==null && other.getRodzajTransakcji()==null) || 
             (this.rodzajTransakcji!=null &&
              this.rodzajTransakcji.equals(other.getRodzajTransakcji()))) &&
            ((this.uzasadnWstrzymZakoncz==null && other.getUzasadnWstrzymZakoncz()==null) || 
             (this.uzasadnWstrzymZakoncz!=null &&
              this.uzasadnWstrzymZakoncz.equals(other.getUzasadnWstrzymZakoncz()))) &&
            ((this.komunikatTransakcjaPDPlan==null && other.getKomunikatTransakcjaPDPlan()==null) || 
             (this.komunikatTransakcjaPDPlan!=null &&
              java.util.Arrays.equals(this.komunikatTransakcjaPDPlan, other.getKomunikatTransakcjaPDPlan())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getDataKoncowa() != null) {
            _hashCode += getDataKoncowa().hashCode();
        }
        if (getDataPoczatkowa() != null) {
            _hashCode += getDataPoczatkowa().hashCode();
        }
        if (getKodEAN() != null) {
            _hashCode += getKodEAN().hashCode();
        }
        if (getRodzajTransakcji() != null) {
            _hashCode += getRodzajTransakcji().hashCode();
        }
        if (getUzasadnWstrzymZakoncz() != null) {
            _hashCode += getUzasadnWstrzymZakoncz().hashCode();
        }
        if (getKomunikatTransakcjaPDPlan() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getKomunikatTransakcjaPDPlan());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getKomunikatTransakcjaPDPlan(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(KomunikatTransakcjaPDMT.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "KomunikatTransakcjaPDMT"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataKoncowa");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dataKoncowa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataPoczatkowa");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dataPoczatkowa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("kodEAN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "kodEAN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rodzajTransakcji");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rodzajTransakcji"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "RodzajTransPlanDostawMT"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("uzasadnWstrzymZakoncz");
        elemField.setXmlName(new javax.xml.namespace.QName("", "uzasadnWstrzymZakoncz"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("komunikatTransakcjaPDPlan");
        elemField.setXmlName(new javax.xml.namespace.QName("", "komunikatTransakcjaPDPlan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "KomunikatTransakcjaPDPlanMT"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
