/**
 * RodzajTransObrotuIStanuMT.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package pl.gov.csioz.zsmopl.mt;

public class RodzajTransObrotuIStanuMT implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected RodzajTransObrotuIStanuMT(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _value1 = "ZKU";
    public static final java.lang.String _value2 = "ZPR";
    public static final java.lang.String _value3 = "ZIM";
    public static final java.lang.String _value4 = "SPR";
    public static final java.lang.String _value5 = "SWY";
    public static final java.lang.String _value6 = "SEK";
    public static final java.lang.String _value7 = "PKU";
    public static final java.lang.String _value8 = "PPR";
    public static final java.lang.String _value9 = "PIM";
    public static final java.lang.String _value10 = "WPR";
    public static final java.lang.String _value11 = "WWY";
    public static final java.lang.String _value12 = "WEK";
    public static final java.lang.String _value13 = "WZR";
    public static final java.lang.String _value14 = "PZR";
    public static final java.lang.String _value15 = "MWG";
    public static final java.lang.String _value16 = "WWG";
    public static final java.lang.String _value17 = "PWY";
    public static final java.lang.String _value18 = "PM+";
    public static final java.lang.String _value19 = "WM-";
    public static final java.lang.String _value20 = "PZO";
    public static final java.lang.String _value21 = "WUT";
    public static final java.lang.String _value22 = "WUI";
    public static final java.lang.String _value23 = "WRO";
    public static final java.lang.String _value24 = "WRW";
    public static final java.lang.String _value25 = "MWO";
    public static final java.lang.String _value26 = "MDO";
    public static final java.lang.String _value27 = "IBO";
    public static final java.lang.String _value28 = "IR+";
    public static final java.lang.String _value29 = "IR-";
    public static final RodzajTransObrotuIStanuMT value1 = new RodzajTransObrotuIStanuMT(_value1);
    public static final RodzajTransObrotuIStanuMT value2 = new RodzajTransObrotuIStanuMT(_value2);
    public static final RodzajTransObrotuIStanuMT value3 = new RodzajTransObrotuIStanuMT(_value3);
    public static final RodzajTransObrotuIStanuMT value4 = new RodzajTransObrotuIStanuMT(_value4);
    public static final RodzajTransObrotuIStanuMT value5 = new RodzajTransObrotuIStanuMT(_value5);
    public static final RodzajTransObrotuIStanuMT value6 = new RodzajTransObrotuIStanuMT(_value6);
    public static final RodzajTransObrotuIStanuMT value7 = new RodzajTransObrotuIStanuMT(_value7);
    public static final RodzajTransObrotuIStanuMT value8 = new RodzajTransObrotuIStanuMT(_value8);
    public static final RodzajTransObrotuIStanuMT value9 = new RodzajTransObrotuIStanuMT(_value9);
    public static final RodzajTransObrotuIStanuMT value10 = new RodzajTransObrotuIStanuMT(_value10);
    public static final RodzajTransObrotuIStanuMT value11 = new RodzajTransObrotuIStanuMT(_value11);
    public static final RodzajTransObrotuIStanuMT value12 = new RodzajTransObrotuIStanuMT(_value12);
    public static final RodzajTransObrotuIStanuMT value13 = new RodzajTransObrotuIStanuMT(_value13);
    public static final RodzajTransObrotuIStanuMT value14 = new RodzajTransObrotuIStanuMT(_value14);
    public static final RodzajTransObrotuIStanuMT value15 = new RodzajTransObrotuIStanuMT(_value15);
    public static final RodzajTransObrotuIStanuMT value16 = new RodzajTransObrotuIStanuMT(_value16);
    public static final RodzajTransObrotuIStanuMT value17 = new RodzajTransObrotuIStanuMT(_value17);
    public static final RodzajTransObrotuIStanuMT value18 = new RodzajTransObrotuIStanuMT(_value18);
    public static final RodzajTransObrotuIStanuMT value19 = new RodzajTransObrotuIStanuMT(_value19);
    public static final RodzajTransObrotuIStanuMT value20 = new RodzajTransObrotuIStanuMT(_value20);
    public static final RodzajTransObrotuIStanuMT value21 = new RodzajTransObrotuIStanuMT(_value21);
    public static final RodzajTransObrotuIStanuMT value22 = new RodzajTransObrotuIStanuMT(_value22);
    public static final RodzajTransObrotuIStanuMT value23 = new RodzajTransObrotuIStanuMT(_value23);
    public static final RodzajTransObrotuIStanuMT value24 = new RodzajTransObrotuIStanuMT(_value24);
    public static final RodzajTransObrotuIStanuMT value25 = new RodzajTransObrotuIStanuMT(_value25);
    public static final RodzajTransObrotuIStanuMT value26 = new RodzajTransObrotuIStanuMT(_value26);
    public static final RodzajTransObrotuIStanuMT value27 = new RodzajTransObrotuIStanuMT(_value27);
    public static final RodzajTransObrotuIStanuMT value28 = new RodzajTransObrotuIStanuMT(_value28);
    public static final RodzajTransObrotuIStanuMT value29 = new RodzajTransObrotuIStanuMT(_value29);
    public java.lang.String getValue() { return _value_;}
    public static RodzajTransObrotuIStanuMT fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        RodzajTransObrotuIStanuMT enumeration = (RodzajTransObrotuIStanuMT)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static RodzajTransObrotuIStanuMT fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RodzajTransObrotuIStanuMT.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://csioz.gov.pl/zsmopl/mt/", "RodzajTransObrotuIStanuMT"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
