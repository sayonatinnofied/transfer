/**
 * ObslugaKomunikatow.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package pl.gov.csioz.zsmopl.ws;

public interface ObslugaKomunikatow extends java.rmi.Remote {
    public pl.gov.csioz.zsmopl.mt.IdentyfikatorKomunikatuMT zapiszKomunikatOS(pl.gov.csioz.zsmopl.mt.KomunikatOSMT komunikatOS) throws java.rmi.RemoteException, pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladTworzeniaIdentyfikatoraKomunikatu, pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladDostepnosci;
    public pl.gov.csioz.zsmopl.mt.IdentyfikatorKomunikatuMT zapiszKomunikatPD(pl.gov.csioz.zsmopl.mt.KomunikatPDMT komunikatPD) throws java.rmi.RemoteException, pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladTworzeniaIdentyfikatoraKomunikatu, pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladDostepnosci;
    public pl.gov.csioz.zsmopl.mt.IdentyfikatorKomunikatuMT zapiszKomunikatZB(pl.gov.csioz.zsmopl.mt.KomunikatZBMT komunikatZB) throws java.rmi.RemoteException, pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladTworzeniaIdentyfikatoraKomunikatu, pl.gov.csioz.zsmopl.ws.obslugakomunikatow.BladDostepnosci;
}
