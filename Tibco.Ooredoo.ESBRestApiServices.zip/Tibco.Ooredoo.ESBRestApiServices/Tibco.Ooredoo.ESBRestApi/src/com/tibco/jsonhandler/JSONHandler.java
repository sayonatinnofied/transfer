/**
 * 
 */
package com.tibco.jsonhandler;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.stream.Collectors;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * @author sayon
 *
 */
public class JSONHandler {

	private static final String JSON_PATH = "D:/temp/sample.json";

	public static String filterJson(String jsonStr, String[] nodeNames) {
		JsonArray jsonArray = null;
		JsonElement parsedJson = new JsonParser().parse(jsonStr);
		jsonArray = parsedJson.getAsJsonArray();

		for (JsonElement el : jsonArray) {
			JsonObject elObj = el.getAsJsonObject();

			for (String nodeName : nodeNames) {
				elObj.remove(nodeName);
				System.out.println("Removed " + nodeName);
			}

		}

		return jsonArray.toString();
	}

	public static void main(String[] args) {
		try {
			BufferedReader br = new BufferedReader(new FileReader(JSON_PATH));
			String jsonStr = br.lines().collect(Collectors.joining());
			System.out.println("String: \n " + jsonStr);
			String[] nodeNames = {"configuration","processes"};
			JSONHandler.filterJson(jsonStr, nodeNames);
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
