--------------------------------------------------------
--  File created - Thursday-November-09-2017   
--------------------------------------------------------
DROP TABLE "INTERFACECONFIG";
--------------------------------------------------------
--  DDL for Table INTERFACECONFIG
--------------------------------------------------------

  CREATE TABLE "INTERFACECONFIG" 
   (	"INTERFACE_ID" VARCHAR2(100 BYTE), 
	"INTERFACE_TYPE" VARCHAR2(100 BYTE), 
	"INTERFACE_DOMAIN" VARCHAR2(100 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into INTERFACECONFIG
SET DEFINE OFF;
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Test','test','test');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Loyalty.manageLoyaltySubscriptions.ReqResp.SOAP','Manage','Loyalty');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.ManageCustomerAgreement.ReqResp.SOAP','Manage','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.RetrieveCustomerAgreement.ReqResp.SOAP','Retrieve','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Resource.RetrieveVoucherDetails.ReqResp.SOAP','Retrieve','Resource');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Billing.RetrieveUsageSummary.ReqResp.SOAP','Retrieve','Billing');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Billing.RetrieveBillingInquiryDetails.ReqResp.SOAP','Retrieve','Billing');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Billing.RetrieveSubscriberBalance.ReqResp.SOAP','Retrieve','Billing');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Common.LogManagement.ReqResp.SOAP','Log','Common');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Common.UserManagementServices.ReqResp.SOAP','Manage','Common');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Common.LogManagementServices.ReqResp.SOAP','Manage','Common');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Account.TerminateAccount.ReqResp.SOAP','Terminate','Account');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Account.UpdateAccount.ReqResp.SOAP','Update','Account');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.CreateCustomer.ReqResp.SOAP','Create','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.ManageCustomerDocument.ReqResp.SOAP','Manage','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.NotifyCustomer.ReqResp.SOAP','Notify','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.UpdateCustomer.ReqResp.SOAP','Update','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.CreateSubscription.ReqResp.SOAP','Create','Subscription');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.RetrieveCustomerDocument.ReqResp.SOAP','Retrieve','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.RetrieveCustomerDocumentDetails.ReqResp.SOAP','Retrieve','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Account.CreateAccount.ReqResp.SOAP','Create','Account');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Account.UpdateManageAccountDetails.ReqResp.SOAP','Update','Account');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Resource.RetrieveResource.ReqResp.SOAP','Retrieve','Account');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.RetrieveCustomerDetails.ReqResp.SOAP','Retrieve','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Payment.ProcessPayment.ReqResp.SOAP','Manage','Payment');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Account.RetrieveAccountdetails.ReqResp.SOAP','Retrieve','Account');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Common.RetrieveMessageTemplate.ReqResp.SOAP','Retrieve','Common');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.ManageCustomerDocumentDetails.ReqResp.SOAP','Manage','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Fulfillment.CreateOrder.ReqResp.SOAP','Create','Fulfillment');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Product.RetrieveDiscountOfferings.ReqResp.SOAP','Retrieve','Product');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.retrieveCreditProfile.ReqResp.SOAP','Notify','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.RetrieveCustomerNotes.ReqResp.SOAP','Retrieve','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.ManageCustomerCreditProfile.ReqResp.SOAP','Manage','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Product.RetrieveProductOfferings.ReqResp.SOAP','Retrieve','Product');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Product.RetrieveProducts.ReqResp.SOAP','Retrieve','Product');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Resource.RetrieveResource.ReqResp.SOAP','Retrieve','Resource');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Subscription.TerminateSubscription.ReqResp.SOAP','Terminate','Subscription');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Subscription.CreateSubscription.ReqResp.SOAP','Create','Subscription');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Subscription.UpdateSubscription.ReqResp.SOAP','Update','Subscription');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Account.AdjustCustomerAccountBalance.ReqResp.SOAP','Adjust','Account');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.UpdateCreditScoreHistory.ReqResp.SOAP','Update','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.ManageCustomerNotes.ReqResp.SOAP','Update','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.ManageCustomerNotes.ReqResp.SOAP','Create','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('ReserveResource.ReserveUnreserveNumber.ReqResp.SOAP','Reserve','ReserveResource');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.retrieveCreditProfile.ReqResp.SOAP','Retrieve','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.RetrieveNotes.ReqResp.SOAP','Retrieve','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Customer.Common.Activator','Common','Customer');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Account.Common.Activator','Common','Account');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Subscription.Common.Activator','Common','Subscription');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Product.RetrieveAvailableProductOfferings.ReqResp.SOAP','Retrieve','Product');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Loyalty.manageLoyaltyPoints.ReqResp.SOAP','Manage','Loyalty');
Insert into INTERFACECONFIG (INTERFACE_ID,INTERFACE_TYPE,INTERFACE_DOMAIN) values ('Loyalty.retrieveLoyaltySubscriptions.ReqResp.SOAP','Retrieve','Loyalty');
insert into interfaceconfig (interface_id,interface_type,interface_domain) values ('Assurance.RetrieveTroubleTicket.ReqResp.SOAP','Retrieve','Assurance');
insert into interfaceconfig (interface_id,interface_type,interface_domain) values ('Logistics.ManageShipmentService.ReqResp.SOAP','Manage','Logistics');
